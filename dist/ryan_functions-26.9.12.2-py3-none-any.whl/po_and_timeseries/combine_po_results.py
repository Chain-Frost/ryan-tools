# ryan-scripts\TUFLOW-python\po_and_timeseries\combine_po_results.py
"""Wrapper Script: Combine TUFLOW PO Results.

This script acts as a mutable wrapper for `ryan_library.orchestrators.tuflow.po_combine`.
It allows users to hard-code default configurations for merging TUFLOW "PO" (Plot Output) CSV files,
while still providing command-line overrides for automation/batch processing.

Key features:
- Merges PO files from found subdirectories.
- Configurable defaults (constants) for manual editing.
- CLI arguments for runtime flexibility.
"""

from pathlib import Path
from typing import Literal

WRAPPER_VERSION = "2026-08-02.1"

CONSOLE_LOG_LEVEL = "INFO"  # or "DEBUG"
# Update this tuple to restrict processing to specific PO/Location values.
# Leave empty to include every location found in the PO files.
LOCATIONS_TO_INCLUDE: tuple[str, ...] = ()
# Choose which data types to include; defaults to PO exports.
INCLUDE_DATA_TYPES: tuple[str, ...] = ("PO",)
# Choose output format: "excel", "parquet", or "both".
EXPORT_MODE: Literal["excel", "parquet", "both"] = "excel"
# Change the working directory
WORKING_DIR: Path = Path(__file__).absolute().parent
# Optional explicit folder roots to scan. If left empty, the wrapper scans WORKING_DIR recursively.
PATHS_TO_PROCESS: tuple[Path, ...] = ()

import argparse

from ryan_library.functions.wrapper_utils import (
    CommonWrapperOptions,
    add_common_cli_arguments,
    add_export_mode_cli_argument,
    change_working_directory,
    parse_common_cli_arguments,
    pause_console,
    print_wrapper_banner,
)
from ryan_library.orchestrators.tuflow.po_combine import main_processing


def main(
    *,
    console_log_level: str | None = None,
    include_data_types: tuple[str, ...] | None = None,
    locations_to_include: tuple[str, ...] | None = None,
    export_mode: Literal["excel", "parquet", "both"] | None = None,
    paths_to_process: tuple[Path, ...] | None = None,
    working_directory: Path | None = None,
) -> int:
    """Main entry point for combining PO results.

    This function sets up the working directory and orchestrates the combination process
    using 'main_processing' from the library. It resolves configuration by prioritizing
    CLI arguments, then falling back to the hard-coded constants in this script.

    Args:
        console_log_level: Overrides the CONSOLE_LOG_LEVEL constant.
        include_data_types: Overrides the INCLUDE_DATA_TYPES constant.
        locations_to_include: Overrides the LOCATIONS_TO_INCLUDE constant.
        export_mode: Overrides the EXPORT_MODE constant.
        paths_to_process: Explicit folder roots to scan for result files.
        working_directory: Overrides the default WORKING_DIR.
    """
    print_wrapper_banner(wrapper_file=Path(__file__), wrapper_version=WRAPPER_VERSION)

    script_directory: Path = working_directory or WORKING_DIR

    if not change_working_directory(target_dir=script_directory):
        return 1

    effective_console_log_level: str = console_log_level or CONSOLE_LOG_LEVEL
    effective_data_types: list[str] = list(include_data_types or INCLUDE_DATA_TYPES)
    effective_locations: tuple[str, ...] | None = locations_to_include or (LOCATIONS_TO_INCLUDE or None)
    effective_export_mode: Literal["excel", "parquet", "both"] = export_mode or EXPORT_MODE
    effective_paths_to_process: list[Path] = list(paths_to_process or PATHS_TO_PROCESS or (script_directory,))

    main_processing(
        paths_to_process=effective_paths_to_process,
        include_data_types=effective_data_types,
        console_log_level=effective_console_log_level,
        locations_to_include=effective_locations,
        export_mode=effective_export_mode,
    )
    return 0


def _parse_cli_arguments() -> argparse.Namespace:
    """Parse command-line arguments to override script defaults.

    Returns:
        argparse.Namespace: Filtered command-line arguments.
    """
    parser = argparse.ArgumentParser(
        description=(
            "Combine TUFLOW PO outputs. Command-line options override the hard-coded values near the top of this file."
        )
    )
    add_common_cli_arguments(parser=parser)
    add_export_mode_cli_argument(parser=parser)
    return parser.parse_args()


if __name__ == "__main__":
    args: argparse.Namespace = _parse_cli_arguments()
    common_options: CommonWrapperOptions = parse_common_cli_arguments(args=args)
    result: int = main(
        console_log_level=common_options.console_log_level,
        include_data_types=common_options.data_types,
        locations_to_include=common_options.locations_to_include,
        export_mode=args.export_mode,
        working_directory=common_options.working_directory,
    )
    print_wrapper_banner(
        wrapper_file=Path(__file__),
        wrapper_version=WRAPPER_VERSION,
        leading_blank_line=True,
    )
    if not common_options.no_pause:
        pause_console()
    raise SystemExit(result)
