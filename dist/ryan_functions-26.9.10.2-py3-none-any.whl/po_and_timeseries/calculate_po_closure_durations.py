# ryan-scripts\\TUFLOW-python\\po_and_timeseries\\calculate_po_closure_durations.py
"""Wrapper for computing closure durations from TUFLOW PO files.

Update ``paths`` or ``thresholds`` below to customise processing.
``data_type`` defaults to ``"Flow"`` and ``allowed_locations`` can
restrict which locations are loaded from the CSV files.
"""

from pathlib import Path
from typing import Literal

WRAPPER_VERSION = "2026-08-02.1"

CONSOLE_LOG_LEVEL = "INFO"
LOCATIONS_TO_INCLUDE: tuple[str, ...] = ()
EXPORT_MODE: Literal["excel", "parquet", "both"] = "excel"
WORKING_DIR: Path = Path(__file__).absolute().parent
# Optional explicit folder roots to scan. If left empty, the wrapper scans WORKING_DIR recursively.
PATHS_TO_PROCESS: tuple[Path, ...] = ()
# WORKING_DIR: Path = Path(r"E:\path\to\custom\directory")

# TODO. expand this to work on a variety of file formats and data types.
# Ultimately, we are just looking at exceedance duration of some form so should not be that hard.

import argparse

from ryan_library.functions.wrapper_utils import (
    CommonWrapperOptions,
    add_common_cli_arguments,
    add_export_mode_cli_argument,
    change_working_directory,
    parse_common_cli_arguments,
    pause_console,
    print_wrapper_banner,
)
from ryan_library.orchestrators.tuflow.closure_durations import run_closure_durations


def main(
    *,
    console_log_level: str | None = None,
    locations_to_include: tuple[str, ...] | None = None,
    export_mode: Literal["excel", "parquet", "both"] | None = None,
    paths_to_process: tuple[Path, ...] | None = None,
    working_directory: Path | None = None,
) -> int:
    print_wrapper_banner(wrapper_file=Path(__file__), wrapper_version=WRAPPER_VERSION)
    script_directory: Path = working_directory or WORKING_DIR
    if not change_working_directory(target_dir=script_directory):
        return 1

    effective_console_log_level: str = console_log_level or CONSOLE_LOG_LEVEL
    effective_locations: tuple[str, ...] | None = (
        locations_to_include or (LOCATIONS_TO_INCLUDE or None)
    )
    effective_export_mode: Literal["excel", "parquet", "both"] = export_mode or EXPORT_MODE
    effective_paths_to_process: list[Path] = list(paths_to_process or PATHS_TO_PROCESS or (script_directory,))
    run_closure_durations(
        paths=effective_paths_to_process,
        thresholds=None,
        data_type="Flow",
        allowed_locations=effective_locations,
        log_level=effective_console_log_level,
        export_mode=effective_export_mode,
    )
    return 0


def _parse_cli_arguments() -> tuple[CommonWrapperOptions, Literal["excel", "parquet", "both"] | None]:
    parser = argparse.ArgumentParser(
        description="Compute closure durations from PO files. Command-line options override the script defaults."
    )
    add_common_cli_arguments(parser=parser)
    add_export_mode_cli_argument(parser=parser)
    args: argparse.Namespace = parser.parse_args()
    common: CommonWrapperOptions = parse_common_cli_arguments(args=args)
    export_mode: Literal["excel", "parquet", "both"] | None = args.export_mode  # type: ignore[attr-defined]
    return common, export_mode


if __name__ == "__main__":
    common_options, cli_export_mode = _parse_cli_arguments()
    result: int = main(
        console_log_level=common_options.console_log_level,
        locations_to_include=common_options.locations_to_include,
        export_mode=cli_export_mode,
        working_directory=common_options.working_directory,
    )
    print_wrapper_banner(
        wrapper_file=Path(__file__),
        wrapper_version=WRAPPER_VERSION,
        leading_blank_line=True,
    )
    if not common_options.no_pause:
        pause_console()
    raise SystemExit(result)
