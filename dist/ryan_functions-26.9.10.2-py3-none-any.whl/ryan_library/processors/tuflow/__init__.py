# ryan_library/processors/tuflow/__init__.py
"""TUFLOW processor package."""

from importlib import import_module
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .maximums_1d import CmxProcessor, NmxProcessor, ccAProcessor
    from .other_processors import (
        ChanProcessor,
        EOFProcessor,
        POMMProcessor,
        POProcessor,
        RLLQmxProcessor,
    )
    from .timeseries_1d import CFProcessor, HProcessor, QProcessor, VProcessor

_PROCESSORS = {
    "ccAProcessor": ".maximums_1d",
    "CmxProcessor": ".maximums_1d",
    "NmxProcessor": ".maximums_1d",
    "CFProcessor": ".timeseries_1d",
    "HProcessor": ".timeseries_1d",
    "QProcessor": ".timeseries_1d",
    "VProcessor": ".timeseries_1d",
    "ChanProcessor": ".other_processors",
    "EOFProcessor": ".other_processors",
    "POMMProcessor": ".other_processors",
    "POProcessor": ".other_processors",
    "RLLQmxProcessor": ".other_processors",
}

__all__ = [
    "CFProcessor",
    "ChanProcessor",
    "CmxProcessor",
    "EOFProcessor",
    "HProcessor",
    "NmxProcessor",
    "POMMProcessor",
    "POProcessor",
    "QProcessor",
    "RLLQmxProcessor",
    "VProcessor",
    "ccAProcessor",
]


def __getattr__(name: str) -> object:
    if name in _PROCESSORS:
        module = import_module(_PROCESSORS[name], __name__)
        obj = getattr(module, name)
        globals()[name] = obj
        return obj
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
