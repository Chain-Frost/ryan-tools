# ryan_library/processors/tuflow/timeseries_1d/VProcessor.py
"""Processor for TUFLOW velocity (``_V``) timeseries data."""

from __future__ import annotations

from ..base_processor import ProcessorStatus
from ..timeseries_processor import TimeSeriesProcessor


class VProcessor(TimeSeriesProcessor):
    """Process ``_V`` CSV exports using the shared timeseries pipeline."""

    def process(self) -> None:
        """Process a ``_V`` CSV using the shared timeseries pipeline."""
        self._process_timeseries_pipeline(data_type="V")

    def process_timeseries_raw_dataframe(self) -> ProcessorStatus:
        """Normalise the melted velocity DataFrame produced by the shared pipeline."""
        return self._normalise_value_dataframe(value_column="V")
