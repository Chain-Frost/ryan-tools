# ryan_library\scripts\tuflow\closure_durations.py

from datetime import datetime
from pathlib import Path
from collections.abc import Iterable
from typing import Literal

import pandas as pd
from loguru import logger

from ryan_library.functions.loguru_helpers import setup_logger
from ryan_library.functions.misc_functions import ExcelExporter
from ryan_library.functions.tuflow.closure_durations import summarise_results
from ryan_library.functions.tuflow.tuflow_common import bulk_read_and_merge_tuflow_csv
from ryan_library.processors.tuflow.base_processor import BaseProcessor
from ryan_library.processors.tuflow.processor_collection import ProcessorCollection

DEFAULT_DATA_TYPES: tuple[str, ...] = ("PO",)


def _first_value(series: pd.Series) -> str:
    """Return the first non-empty string value from ``series``."""
    for value in series:
        if pd.notna(value):
            text: str = str(value).strip()
            if text:
                return text
    return ""


def _median_timestep(time_values: pd.Series) -> float | None:
    """Return the median timestep from numeric ``time_values``."""
    numeric = pd.to_numeric(time_values, errors="coerce").dropna().unique()
    if len(numeric) < 2:
        return None
    sorted_times = pd.Series(numeric).sort_values(ignore_index=True)
    diffs = sorted_times.diff().dropna()
    if diffs.empty:
        return None
    return float(diffs.median())


def _calculate_threshold_durations(
    po_df: pd.DataFrame,
    thresholds: list[float],
    measurement_type: str,
) -> pd.DataFrame:
    """Return a DataFrame of duration exceedances for the requested measurement type."""

    if po_df.empty:
        return pd.DataFrame()

    filtered = po_df.copy()
    filtered["Type"] = filtered["Type"].astype(str).str.strip()
    filtered = filtered[filtered["Type"].str.lower() == measurement_type.lower()]
    if filtered.empty:
        logger.warning(f"No PO rows found for measurement type '{measurement_type}'. Skipping.")
        return pd.DataFrame()

    filtered["Time"] = pd.to_numeric(filtered["Time"], errors="coerce")
    filtered["Value"] = pd.to_numeric(filtered["Value"], errors="coerce")
    filtered = filtered.dropna(subset=["Time", "Value", "Location"])

    group_keys: list[str] = [
        "directory_path",
        "trim_runcode",
        "Location",
        "aep_text",
        "duration_text",
        "tp_text",
    ]
    available_keys: list[str] = [key for key in group_keys if key in filtered.columns]
    if "Location" not in available_keys:
        logger.warning("PO data is missing a 'Location' column. Skipping duration calculation.")
        return pd.DataFrame()

    records: list[dict[str, object]] = []
    for _, group in filtered.groupby(available_keys, dropna=False):
        timestep: float | None = _median_timestep(group["Time"])
        if timestep is None:
            location_label: str = _first_value(group["Location"])
            logger.warning(f"Unable to determine timestep for group with Location '{location_label}'. Skipping.")
            continue

        out_path: str = _first_value(group["directory_path"]) if "directory_path" in group.columns else ""
        aep = _first_value(group["aep_text"]) if "aep_text" in group.columns else ""
        duration = _first_value(group["duration_text"]) if "duration_text" in group.columns else ""
        tp = _first_value(group["tp_text"]) if "tp_text" in group.columns else ""
        location = _first_value(group["Location"])

        for threshold in thresholds:
            exceed_count: int = int((group["Value"] > threshold).sum())
            if exceed_count == 0:
                continue
            records.append(
                {
                    "AEP": aep,
                    "Duration": duration,
                    "TP": tp,
                    "Location": location,
                    "ThresholdFlow": float(threshold),
                    "Duration_Exceeding": float(exceed_count) * timestep,
                    "out_path": out_path,
                }
            )

    return pd.DataFrame(records)


def _collect_po_dataframe(collection: ProcessorCollection) -> pd.DataFrame:
    """Concatenate PO processor DataFrames into a single DataFrame."""
    frames: list[pd.DataFrame] = [processor.df for processor in collection.processors if processor.data_type == "PO"]
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def run_closure_durations(
    paths: Iterable[Path] | None = None,
    thresholds: list[float] | None = None,
    *,
    data_type: str = "Flow",
    allowed_locations: tuple[str, ...] | None = None,
    log_level: str = "INFO",
    export_mode: Literal["excel", "parquet", "both"] = "excel",
    output_directory: Path | None = None,
) -> None:
    """Process PO files under ``paths`` using the TUFLOW processors and export closure durations."""
    if paths is None:
        paths = [Path.cwd()]
    if thresholds is None:
        values: set[int] = set(list(range(1, 10)) + list(range(10, 100, 2)) + list(range(100, 2100, 10)))
        thresholds = [float(v) for v in values]

    normalized_locations: frozenset[str] = BaseProcessor.normalize_locations(allowed_locations)

    with setup_logger(console_log_level=log_level) as log_queue:
        logger.info("Starting PO closure duration processing.")

        collection: ProcessorCollection = bulk_read_and_merge_tuflow_csv(
            paths_to_process=list(paths),
            include_data_types=list(DEFAULT_DATA_TYPES),
            log_queue=log_queue,
        )

        if normalized_locations:
            collection.filter_locations(locations=normalized_locations)

        if not collection.processors:
            logger.warning("No PO CSV files were processed.")
            return

        po_df: pd.DataFrame = _collect_po_dataframe(collection=collection)
        if po_df.empty:
            logger.warning("PO processors returned no data. Skipping export.")
            return

        result_df: pd.DataFrame = _calculate_threshold_durations(
            po_df=po_df,
            thresholds=thresholds,
            measurement_type=data_type,
        )
        if result_df.empty:
            logger.warning("No hydrograph data exceeded the provided thresholds.")
            return

        summary_df: pd.DataFrame = summarise_results(df=result_df)
        if summary_df.empty:
            logger.warning("No summary rows generated from PO closure durations.")
            return

        summary_df["AEP_sort_key"] = summary_df["AEP"].str.extract(r"([0-9]*\.?[0-9]+)")[0].astype(dtype=float)
        summary_df.sort_values(
            by=["Path", "Location", "ThresholdFlow", "AEP_sort_key"],
            ignore_index=True,
            inplace=True,
        )
        summary_df.drop(columns="AEP_sort_key", inplace=True)

        timestamp: str = datetime.now().strftime(format="%Y%m%d-%H%M")
        exporter = ExcelExporter()
        exporter.export_dataframes(
            export_dict={
                f"{timestamp}_closure_durations": {
                    "dataframes": [result_df, summary_df],
                    "sheets": ["durations", "summary"],
                }
            },
            output_directory=output_directory,
            export_mode=export_mode,
            parquet_compression="gzip",
        )

        logger.info("Closure duration processing complete.")
