# ryan_library\scripts\tuflow\closure_durations.py

from datetime import datetime
from pathlib import Path
from collections.abc import Iterable

from pandas import DataFrame
from loguru import logger

from ryan_library.functions.loguru_helpers import setup_logger
from ryan_library.functions.tuflow.closure_durations_functions import (
    calculate_threshold_durations,
    collect_po_data,
    summarise_results,
)
from ryan_library.functions.tuflow.tuflow_common import bulk_read_and_merge_tuflow_csv
from ryan_library.processors.tuflow.base_processor import BaseProcessor
from ryan_library.processors.tuflow.processor_collection import ProcessorCollection


def run_closure_durations(
    paths: Iterable[Path] | None = None,
    thresholds: list[float] | None = None,
    *,
    data_type: str = "Flow",
    allowed_locations: tuple[str, ...] | None = None,
    log_level: str = "INFO",
) -> None:
    """Process ``*_PO.csv`` files under ``paths`` and report closure durations."""
    if paths is None:
        paths = [Path.cwd()]
    if thresholds is None:
        values: set[int] = set(list(range(1, 10)) + list(range(10, 100, 2)) + list(range(100, 2100, 10)))
        thresholds = [float(v) for v in values]
    normalized_locations: frozenset[str] = BaseProcessor.normalize_locations(allowed_locations)

    with setup_logger(console_log_level=log_level) as log_queue:
        collection: ProcessorCollection = bulk_read_and_merge_tuflow_csv(
            paths_to_process=list(paths),
            include_data_types=["PO"],
            log_queue=log_queue,
        )

        if normalized_locations:
            collection.filter_locations(locations=normalized_locations)

        if not collection.processors:
            logger.warning("No PO CSV files were processed.")
            return

        po_df: DataFrame = _collect_po_data(collection=collection)
        if po_df.empty:
            logger.warning("PO processors returned no data. Skipping export.")
            return

        result_df: DataFrame = _calculate_threshold_durations(
            po_df=po_df,
            thresholds=thresholds,
            measurement_type=data_type,
        )
        if result_df.empty:
            logger.warning("No hydrograph data processed.")
            return

        timestamp: str = datetime.now().strftime(format="%Y%m%d-%H%M")
        result_df.to_parquet(path=f"{timestamp}_durex.parquet.gzip", compression="gzip")
        result_df.to_csv(path_or_buf=f"{timestamp}_durex.csv", index=False)
        summary_df: DataFrame = summarise_results(df=result_df)
        summary_df["AEP_sort_key"] = summary_df["AEP"].str.extract(r"([0-9]*\.?[0-9]+)")[0].astype(dtype=float)
        summary_df.sort_values(
            by=["Path", "Location", "ThresholdFlow", "AEP_sort_key"], ignore_index=True, inplace=True
        )
        summary_df.drop(columns="AEP_sort_key", inplace=True)
        summary_df.to_csv(path_or_buf=f"{timestamp}_QvsTexc.csv", index=False)
        logger.info("Processing complete")
