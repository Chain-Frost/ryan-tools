"""Strict versioned project-file parsing and deterministic JSON serialization."""

import json
import tomllib
from pathlib import Path
from typing import cast

from culvert_solver import (
    BoundedParameterSpec,
    HydraulicResultStatus,
    HydraulicUncertaintyParameter,
    HydraulicUncertaintyUnit,
    ManningChannelTailwater,
    ParameterBounds,
    RectangularChannel,
    SourceReference,
    TailwaterCondition,
    TrapezoidalChannel,
    UniformParameterSpec,
)

from ...classes.culvert.alternative import Alternative
from ...classes.culvert.criteria import DesignCriteria
from ...classes.culvert.crossing import (
    CircularBarrelDefinition,
    CrossingDefinition,
    CulvertGroupDefinition,
    CulvertMaterialName,
    RectangularBarrelDefinition,
    RoadwayCrestPointDefinition,
    RoadwayDefinition,
    RoadwayOvertoppingDefinition,
    RoadwayProfileDefinition,
    RoadwaySurfaceName,
)
from ...classes.culvert.project import CulvertProject
from ...classes.culvert.scenario import Scenario
from ...classes.culvert.uncertainty import UncertaintyParameterSpec, UncertaintySamplingMode, UncertaintyStudy

SCHEMA_VERSION = 1


def _mapping(value: object, name: str) -> dict[str, object]:
    if not isinstance(value, dict):
        msg = f"{name} must be an object/table."
        raise ValueError(msg)
    raw = cast("dict[object, object]", value)
    if not all(isinstance(key, str) for key in raw):
        msg = f"{name} must contain only string keys."
        raise ValueError(msg)
    return cast("dict[str, object]", raw)


def _reject_unknown(data: dict[str, object], allowed: set[str], name: str) -> None:
    if unknown := sorted(data.keys() - allowed):
        msg = f"{name} contains unknown field(s): {', '.join(unknown)}."
        raise ValueError(msg)


def _list(value: object, name: str) -> list[object]:
    if not isinstance(value, list):
        msg = f"{name} must be an array."
        raise ValueError(msg)
    return cast("list[object]", value)


def _text(data: dict[str, object], key: str) -> str:
    value = data.get(key)
    if not isinstance(value, str) or not value.strip():
        msg = f"{key} must be nonempty text."
        raise ValueError(msg)
    return value.strip()


def _optional_text(data: dict[str, object], key: str) -> str | None:
    return None if data.get(key) is None else _text(data, key)


def _number(data: dict[str, object], key: str) -> float:
    value = data.get(key)
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        msg = f"{key} must be numeric."
        raise ValueError(msg)
    return float(value)


def _integer(data: dict[str, object], key: str, default: int | None = None) -> int:
    value = data.get(key, default)
    if isinstance(value, bool) or not isinstance(value, int):
        msg = f"{key} must be an integer."
        raise ValueError(msg)
    return value


def _optional_number(data: dict[str, object], key: str) -> float | None:
    return None if data.get(key) is None else _number(data, key)


def _metadata(data: dict[str, object]) -> tuple[str | None, str]:
    source = _optional_text(data, "source")
    notes = data.get("notes", "")
    if not isinstance(notes, str):
        msg = "notes must be text."
        raise ValueError(msg)
    return source, notes


def _parse_barrel(value: object) -> RectangularBarrelDefinition | CircularBarrelDefinition:
    data = _mapping(value, "barrel")
    common = {
        "shape",
        "material",
        "length_m",
        "inlet_invert_elevation_m",
        "outlet_invert_elevation_m",
        "roughness_manning_n",
        "label",
    }
    shape = _text(data, "shape")
    if shape == "rectangular":
        dimensions = {"span_mm", "rise_mm"}
    elif shape == "circular":
        dimensions = {"diameter_mm"}
    else:
        msg = "barrel shape must be 'rectangular' or 'circular'."
        raise ValueError(msg)
    _reject_unknown(data, common | dimensions, "barrel")
    label = data.get("label", "")
    if not isinstance(label, str):
        msg = "barrel label must be text."
        raise ValueError(msg)
    material = CulvertMaterialName(_text(data, "material"))
    length = _number(data, "length_m")
    inlet_invert = _number(data, "inlet_invert_elevation_m")
    outlet_invert = _number(data, "outlet_invert_elevation_m")
    roughness = _number(data, "roughness_manning_n")

    if shape == "rectangular":
        return RectangularBarrelDefinition(
            span_mm=_number(data, "span_mm"),
            rise_mm=_number(data, "rise_mm"),
            length=length,
            inlet_invert=inlet_invert,
            outlet_invert=outlet_invert,
            roughness=roughness,
            material=material,
            label=label,
        )
    return CircularBarrelDefinition(
        diameter_mm=_number(data, "diameter_mm"),
        length=length,
        inlet_invert=inlet_invert,
        outlet_invert=outlet_invert,
        roughness=roughness,
        material=material,
        label=label,
    )


def _parse_roadway_surface(data: dict[str, object]) -> RoadwaySurfaceName | None:
    value = data.get("surface")
    if value is None:
        return None
    if not isinstance(value, str):
        msg = "roadway surface must be text."
        raise ValueError(msg)
    try:
        return RoadwaySurfaceName(value)
    except ValueError as exc:
        msg = "roadway surface must be 'paved' or 'gravel'."
        raise ValueError(msg) from exc


def _parse_roadway(value: object) -> RoadwayOvertoppingDefinition:
    data = _mapping(value, "roadway")
    roadway_type_raw = data.get("type", "constant")
    if not isinstance(roadway_type_raw, str):
        msg = "roadway type must be text."
        raise ValueError(msg)
    roadway_type = roadway_type_raw.strip().lower()
    label = data.get("label", "")
    if not isinstance(label, str):
        msg = "roadway label must be text."
        raise ValueError(msg)
    surface = _parse_roadway_surface(data)

    if roadway_type == "constant":
        _reject_unknown(
            data,
            {
                "type",
                "crest_elevation_m",
                "crest_length_m",
                "discharge_coefficient",
                "surface",
                "label",
            },
            "roadway",
        )
        return RoadwayDefinition(
            crest_elevation=_number(data, "crest_elevation_m"),
            crest_length=_number(data, "crest_length_m"),
            discharge_coefficient=_number(data, "discharge_coefficient"),
            label=label,
            surface=surface,
        )

    if roadway_type == "profile":
        _reject_unknown(
            data,
            {"type", "points", "discharge_coefficient", "surface", "label"},
            "roadway",
        )
        points: list[RoadwayCrestPointDefinition] = []
        for index, raw_point in enumerate(_list(data.get("points"), "roadway.points")):
            point = _mapping(raw_point, f"roadway.points[{index}]")
            _reject_unknown(point, {"station_m", "elevation_m"}, f"roadway.points[{index}]")
            points.append(
                RoadwayCrestPointDefinition(
                    station=_number(point, "station_m"),
                    elevation=_number(point, "elevation_m"),
                )
            )
        return RoadwayProfileDefinition(
            points=tuple(points),
            discharge_coefficient=_number(data, "discharge_coefficient"),
            label=label,
            surface=surface,
        )

    msg = "roadway type must be 'constant' or 'profile'."
    raise ValueError(msg)


def _parse_crossing(value: object) -> CrossingDefinition:
    data = _mapping(value, "crossing")
    _reject_unknown(data, {"name", "groups", "roadway", "source", "notes"}, "crossing")
    groups: list[CulvertGroupDefinition] = []
    for raw_group in _list(data.get("groups"), "groups"):
        group = _mapping(raw_group, "group")
        _reject_unknown(group, {"name", "quantity", "barrel"}, "group")
        groups.append(
            CulvertGroupDefinition(
                name=_text(group, "name"),
                barrel=_parse_barrel(group.get("barrel")),
                quantity=_integer(group, "quantity", 1),
            )
        )
    source, notes = _metadata(data)
    roadway_value = data.get("roadway")
    return CrossingDefinition(
        name=_text(data, "name"),
        groups=tuple(groups),
        roadway=None if roadway_value is None else _parse_roadway(roadway_value),
        source=source,
        notes=notes,
    )


def _parse_tailwater(value: object) -> TailwaterCondition | ManningChannelTailwater:
    data = _mapping(value, "tailwater")
    tailwater_type = _text(data, "type")
    if tailwater_type == "fixed":
        _reject_unknown(data, {"type", "elevation_m"}, "tailwater")
        return TailwaterCondition(elevation=_number(data, "elevation_m"))
    if tailwater_type != "manning_channel":
        msg = "tailwater type must be 'fixed' or 'manning_channel'."
        raise ValueError(msg)
    _reject_unknown(
        data,
        {
            "type",
            "channel_invert_elevation_m",
            "roughness_manning_n",
            "friction_slope",
            "section",
        },
        "tailwater",
    )
    section_data = _mapping(data.get("section"), "tailwater.section")
    shape = _text(section_data, "shape")
    if shape == "rectangular":
        _reject_unknown(section_data, {"shape", "bottom_width_m"}, "tailwater.section")
        section = RectangularChannel(bottom_width=_number(section_data, "bottom_width_m"))
    elif shape == "trapezoidal":
        _reject_unknown(
            section_data,
            {
                "shape",
                "bottom_width_m",
                "left_side_slope_h_to_v",
                "right_side_slope_h_to_v",
            },
            "tailwater.section",
        )
        section = TrapezoidalChannel(
            bottom_width=_number(section_data, "bottom_width_m"),
            left_side_slope=_number(section_data, "left_side_slope_h_to_v"),
            right_side_slope=_number(section_data, "right_side_slope_h_to_v"),
        )
    else:
        msg = "tailwater.section shape must be 'rectangular' or 'trapezoidal'."
        raise ValueError(msg)
    return ManningChannelTailwater(
        section=section,
        channel_invert_elevation=_number(data, "channel_invert_elevation_m"),
        roughness=_number(data, "roughness_manning_n"),
        friction_slope=_number(data, "friction_slope"),
    )


def _parse_scenario(value: object) -> Scenario:
    data = _mapping(value, "scenario")
    _reject_unknown(
        data,
        {"name", "discharge_m3s", "aep_percent", "tailwater", "source", "notes"},
        "scenario",
    )
    source, notes = _metadata(data)
    return Scenario(
        name=_text(data, "name"),
        discharge=_number(data, "discharge_m3s"),
        tailwater=_parse_tailwater(data.get("tailwater")),
        aep_percent=_optional_number(data, "aep_percent"),
        source=source,
        notes=notes,
    )


def _parse_design_criteria(value: object) -> DesignCriteria:
    data = _mapping(value, "design_criteria")
    _reject_unknown(
        data,
        {
            "maximum_headwater_elevation_m",
            "maximum_headwater_depth_m",
            "maximum_headwater_ratio",
            "minimum_freeboard_m",
            "maximum_outlet_velocity_ms",
            "maximum_roadway_discharge_m3s",
            "maximum_barrel_count",
            "maximum_total_structure_width_m",
            "require_resolved_result",
        },
        "design_criteria",
    )
    resolved = data.get("require_resolved_result", True)
    if not isinstance(resolved, bool):
        msg = "require_resolved_result must be boolean."
        raise ValueError(msg)
    return DesignCriteria(
        maximum_headwater_elevation=_optional_number(data, "maximum_headwater_elevation_m"),
        maximum_headwater_depth=_optional_number(data, "maximum_headwater_depth_m"),
        maximum_headwater_ratio=_optional_number(data, "maximum_headwater_ratio"),
        minimum_freeboard=_optional_number(data, "minimum_freeboard_m"),
        maximum_outlet_velocity=_optional_number(data, "maximum_outlet_velocity_ms"),
        maximum_roadway_discharge=_optional_number(data, "maximum_roadway_discharge_m3s"),
        maximum_barrel_count=(
            None if data.get("maximum_barrel_count") is None else _integer(data, "maximum_barrel_count")
        ),
        maximum_total_structure_width=_optional_number(data, "maximum_total_structure_width_m"),
        require_resolved_result=resolved,
    )


def _parse_parameter(value: object, mode: UncertaintySamplingMode) -> UncertaintyParameterSpec:
    data = _mapping(value, "uncertainty parameter")
    _reject_unknown(data, {"parameter", "bounds", "source"}, "uncertainty parameter")
    bounds = _mapping(data.get("bounds"), "parameter bounds")
    _reject_unknown(bounds, {"lower", "upper", "unit"}, "parameter bounds")
    source = _mapping(data.get("source"), "parameter source")
    _reject_unknown(
        source, {"source_id", "publication", "edition", "locator", "url", "applicability", "notes"}, "parameter source"
    )
    _, notes = _metadata({"notes": source.get("notes", "")})
    reference = SourceReference(
        source_id=_text(source, "source_id"),
        publication=_text(source, "publication"),
        edition=_text(source, "edition"),
        locator=_text(source, "locator"),
        url=_optional_text(source, "url"),
        applicability=_text(source, "applicability"),
        notes=notes,
    )
    spec_type = BoundedParameterSpec if mode is UncertaintySamplingMode.BOUNDED_SWEEP else UniformParameterSpec
    return spec_type(
        parameter=HydraulicUncertaintyParameter(_text(data, "parameter")),
        bounds=ParameterBounds(
            lower=_number(bounds, "lower"),
            upper=_number(bounds, "upper"),
            unit=HydraulicUncertaintyUnit(_text(bounds, "unit")),
        ),
        source=reference,
    )


def _names(data: dict[str, object], key: str) -> tuple[str, ...]:
    values = _list(data.get(key, []), key)
    return tuple(_text({key: value}, key) for value in values)


def _parse_study(value: object) -> UncertaintyStudy:
    data = _mapping(value, "uncertainty study")
    _reject_unknown(
        data,
        {
            "name",
            "sampling_mode",
            "parameters",
            "sample_count",
            "seed",
            "crossing_names",
            "scenario_names",
            "alternative_names",
            "include_base_crossings",
            "include_alternatives",
            "maximum_evaluations",
            "percentiles",
            "aggregation_statuses",
            "source",
            "notes",
        },
        "uncertainty study",
    )
    mode = UncertaintySamplingMode(_text(data, "sampling_mode"))
    include_base = data.get("include_base_crossings", True)
    if not isinstance(include_base, bool):
        msg = "include_base_crossings must be boolean."
        raise ValueError(msg)
    include_alternatives = data.get("include_alternatives", True)
    if not isinstance(include_alternatives, bool):
        msg = "include_alternatives must be boolean."
        raise ValueError(msg)
    percentiles = tuple(
        _number({"percentile": value}, "percentile")
        for value in _list(data.get("percentiles", [5, 50, 95]), "percentiles")
    )
    statuses = tuple(
        HydraulicResultStatus(_text({"status": value}, "status"))
        for value in _list(data.get("aggregation_statuses", ["valid", "valid_with_advisory"]), "aggregation_statuses")
    )
    source, notes = _metadata(data)
    return UncertaintyStudy(
        name=_text(data, "name"),
        sampling_mode=mode,
        parameters=tuple(_parse_parameter(item, mode) for item in _list(data.get("parameters"), "parameters")),
        sample_count=_integer(data, "sample_count"),
        seed=None if data.get("seed") is None else _integer(data, "seed"),
        crossing_names=_names(data, "crossing_names"),
        scenario_names=_names(data, "scenario_names"),
        alternative_names=_names(data, "alternative_names"),
        include_base_crossings=include_base,
        include_alternatives=include_alternatives,
        maximum_evaluations=_integer(data, "maximum_evaluations", 10000),
        percentiles=percentiles,
        aggregation_statuses=statuses,
        source=source,
        notes=notes,
    )


def uncertainty_study_record(study: UncertaintyStudy) -> dict[str, object]:
    """Serialize study policy and public hydraulic bounds/source contracts."""
    return {
        "name": study.name,
        "sampling_mode": study.sampling_mode.value,
        "sample_count": study.sample_count,
        "seed": study.seed,
        "crossing_names": list(study.crossing_names),
        "scenario_names": list(study.scenario_names),
        "alternative_names": list(study.alternative_names),
        "include_base_crossings": study.include_base_crossings,
        "include_alternatives": study.include_alternatives,
        "maximum_evaluations": study.maximum_evaluations,
        "percentiles": list(study.percentiles),
        "aggregation_statuses": [status.value for status in study.aggregation_statuses],
        "source": study.source,
        "notes": study.notes,
        "parameters": [
            {
                "parameter": spec.parameter.value,
                "bounds": {"lower": spec.bounds.lower, "upper": spec.bounds.upper, "unit": spec.bounds.unit.value},
                "source": {
                    "source_id": spec.source.source_id,
                    "publication": spec.source.publication,
                    "edition": spec.source.edition,
                    "locator": spec.source.locator,
                    "url": spec.source.url,
                    "applicability": spec.source.applicability,
                    "notes": spec.source.notes,
                },
            }
            for spec in study.parameters
        ],
    }


def _parse_project(raw: object) -> CulvertProject:
    data = _mapping(raw, "project")
    _reject_unknown(
        data,
        {
            "schema_version",
            "name",
            "crossings",
            "scenarios",
            "alternatives",
            "design_criteria",
            "source",
            "notes",
            "uncertainty_studies",
        },
        "project",
    )
    schema_version = _integer(data, "schema_version")
    if schema_version != SCHEMA_VERSION:
        msg = f"Unsupported culvert project schema_version {schema_version!r}; supported version: {SCHEMA_VERSION}."
        raise ValueError(msg)

    alternatives: list[Alternative] = []
    for raw_alternative in _list(data.get("alternatives", []), "alternatives"):
        item = _mapping(raw_alternative, "alternative")
        _reject_unknown(item, {"name", "crossing", "source", "notes"}, "alternative")
        source, notes = _metadata(item)
        alternatives.append(
            Alternative(
                name=_text(item, "name"),
                crossing=_parse_crossing(item.get("crossing")),
                source=source,
                notes=notes,
            )
        )

    source, notes = _metadata(data)
    return CulvertProject(
        name=_text(data, "name"),
        crossings=tuple(_parse_crossing(item) for item in _list(data.get("crossings"), "crossings")),
        scenarios=tuple(_parse_scenario(item) for item in _list(data.get("scenarios"), "scenarios")),
        alternatives=tuple(alternatives),
        design_criteria=(
            None if data.get("design_criteria") is None else _parse_design_criteria(data["design_criteria"])
        ),
        schema_version=schema_version,
        source=source,
        notes=notes,
        uncertainty_studies=tuple(
            _parse_study(value) for value in _list(data.get("uncertainty_studies", []), "uncertainty_studies")
        ),
    )


def load_project(path: Path) -> CulvertProject:
    """Load a strict schema-versioned JSON or TOML culvert project."""
    source = Path(path)
    if source.suffix.lower() == ".json":
        payload = cast(object, json.loads(source.read_text(encoding="utf-8")))
    elif source.suffix.lower() == ".toml":
        with source.open("rb") as stream:
            payload = cast(object, tomllib.load(stream))
    else:
        msg = "Culvert project files must use a .json or .toml extension."
        raise ValueError(msg)
    return _parse_project(payload)


def load_project_json(path: Path) -> CulvertProject:
    """Load a strict schema-versioned JSON culvert project."""
    if Path(path).suffix.lower() != ".json":
        msg = "load_project_json requires a .json file."
        raise ValueError(msg)
    return load_project(path)


def _tailwater_record(tailwater: object) -> dict[str, object]:
    if isinstance(tailwater, TailwaterCondition):
        return {"type": "fixed", "elevation_m": tailwater.elevation}
    if isinstance(tailwater, ManningChannelTailwater):
        section = tailwater.section
        if isinstance(section, RectangularChannel):
            section_record: dict[str, object] = {
                "shape": "rectangular",
                "bottom_width_m": section.bottom_width,
            }
        elif isinstance(section, TrapezoidalChannel):
            section_record = {
                "shape": "trapezoidal",
                "bottom_width_m": section.bottom_width,
                "left_side_slope_h_to_v": section.left_side_slope,
                "right_side_slope_h_to_v": section.right_side_slope,
            }
        else:
            msg = f"Unsupported tailwater section type: {type(section).__name__}."
            raise TypeError(msg)
        return {
            "type": "manning_channel",
            "channel_invert_elevation_m": tailwater.channel_invert_elevation,
            "roughness_manning_n": tailwater.roughness,
            "friction_slope": tailwater.friction_slope,
            "section": section_record,
        }
    if isinstance(tailwater, bool) or not isinstance(tailwater, (float, int)):
        msg = f"Unsupported tailwater type for serialization: {type(tailwater).__name__}."
        raise TypeError(msg)
    return {"type": "fixed", "elevation_m": float(tailwater)}


def _roadway_record(roadway: RoadwayOvertoppingDefinition) -> dict[str, object]:
    common: dict[str, object] = {
        "discharge_coefficient": roadway.discharge_coefficient,
    }
    if roadway.label:
        common["label"] = roadway.label
    if roadway.surface is not None:
        common["surface"] = roadway.surface.value

    roadway_value: object = roadway
    # Keep runtime rejection for callers outside the typed API.
    if not isinstance(roadway_value, (RoadwayDefinition, RoadwayProfileDefinition)):  # pyright: ignore[reportUnnecessaryIsInstance]
        msg = f"Unsupported roadway definition type: {type(roadway_value).__name__}"
        raise TypeError(msg)
    if isinstance(roadway, RoadwayDefinition):
        return {
            "type": "constant",
            "crest_elevation_m": roadway.crest_elevation,
            "crest_length_m": roadway.crest_length,
            **common,
        }
    return {
        "type": "profile",
        "points": [{"station_m": point.station, "elevation_m": point.elevation} for point in roadway.points],
        **common,
    }


def _crossing_record(crossing: CrossingDefinition) -> dict[str, object]:
    groups: list[dict[str, object]] = []
    for group in crossing.groups:
        barrel = group.barrel
        record: dict[str, object] = {
            "material": barrel.material.value,
            "length_m": barrel.length,
            "inlet_invert_elevation_m": barrel.inlet_invert,
            "outlet_invert_elevation_m": barrel.outlet_invert,
            "roughness_manning_n": barrel.roughness,
        }
        if barrel.label:
            record["label"] = barrel.label
        if isinstance(barrel, CircularBarrelDefinition):
            record.update(shape="circular", diameter_mm=barrel.diameter_mm)
        else:
            record.update(shape="rectangular", span_mm=barrel.span_mm, rise_mm=barrel.rise_mm)
        groups.append({"name": group.name, "quantity": group.quantity, "barrel": record})

    result: dict[str, object] = {"name": crossing.name, "groups": groups}
    if crossing.roadway is not None:
        result["roadway"] = _roadway_record(crossing.roadway)
    if crossing.source is not None:
        result["source"] = crossing.source
    if crossing.notes:
        result["notes"] = crossing.notes
    return result


def _scenario_record(scenario: Scenario) -> dict[str, object]:
    item: dict[str, object] = {
        "name": scenario.name,
        "discharge_m3s": scenario.discharge,
        "tailwater": _tailwater_record(scenario.tailwater),
    }
    if scenario.aep_percent is not None:
        item["aep_percent"] = scenario.aep_percent
    if scenario.source is not None:
        item["source"] = scenario.source
    if scenario.notes:
        item["notes"] = scenario.notes
    return item


def _alternative_record(alternative: Alternative) -> dict[str, object]:
    item: dict[str, object] = {
        "name": alternative.name,
        "crossing": _crossing_record(alternative.crossing),
    }
    if alternative.source is not None:
        item["source"] = alternative.source
    if alternative.notes:
        item["notes"] = alternative.notes
    return item


def _criteria_record(criteria: DesignCriteria) -> dict[str, object]:
    return {
        "maximum_headwater_elevation_m": criteria.maximum_headwater_elevation,
        "maximum_headwater_depth_m": criteria.maximum_headwater_depth,
        "maximum_headwater_ratio": criteria.maximum_headwater_ratio,
        "minimum_freeboard_m": criteria.minimum_freeboard,
        "maximum_outlet_velocity_ms": criteria.maximum_outlet_velocity,
        "maximum_roadway_discharge_m3s": criteria.maximum_roadway_discharge,
        "maximum_barrel_count": criteria.maximum_barrel_count,
        "maximum_total_structure_width_m": criteria.maximum_total_structure_width,
        "require_resolved_result": criteria.require_resolved_result,
    }


def project_record(project: CulvertProject) -> dict[str, object]:
    """Return the canonical deterministic interchange representation."""
    result: dict[str, object] = {
        "schema_version": project.schema_version,
        "name": project.name,
        "crossings": [_crossing_record(crossing) for crossing in project.crossings],
        "scenarios": [_scenario_record(scenario) for scenario in project.scenarios],
        "alternatives": [_alternative_record(alternative) for alternative in project.alternatives],
    }
    if project.uncertainty_studies:
        result["uncertainty_studies"] = [uncertainty_study_record(study) for study in project.uncertainty_studies]
    if project.design_criteria is not None:
        result["design_criteria"] = _criteria_record(project.design_criteria)
    if project.source is not None:
        result["source"] = project.source
    if project.notes:
        result["notes"] = project.notes
    return result


def export_project_json(project: CulvertProject, path: Path) -> Path:
    """Write canonical JSON with stable field and collection ordering."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(project_record(project), indent=2) + "\n", encoding="utf-8")
    return target
