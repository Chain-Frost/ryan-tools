# ryan_library/scripts/tuflow/pomm_combine.py
"""Compatibility wrapper for POMM combination utilities."""

from ryan_library.functions.tuflow.pomm_combine import main_processing

__all__ = ["main_processing"]
