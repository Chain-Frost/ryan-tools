"""Compatibility package for GDAL orchestrators."""

from importlib import import_module
import sys

from ryan_library.scripts._compat import warn_deprecated

warn_deprecated("ryan_library.scripts.gdal", "ryan_library.orchestrators.gdal")

_module = import_module("ryan_library.orchestrators.gdal")
sys.modules[__name__] = _module
