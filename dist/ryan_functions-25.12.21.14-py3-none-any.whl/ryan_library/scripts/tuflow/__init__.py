"""Compatibility package for TUFLOW orchestrators."""

from importlib import import_module
import sys

from ryan_library.scripts._compat import warn_deprecated

warn_deprecated("ryan_library.scripts.tuflow", "ryan_library.orchestrators.tuflow")

_module = import_module("ryan_library.orchestrators.tuflow")
sys.modules[__name__] = _module
