"""Compatibility imports for legacy script entry points."""

from importlib import import_module
import sys

from ryan_library.scripts._compat import warn_deprecated

warn_deprecated(module_name="ryan_library.scripts", replacement="ryan_library.orchestrators")

_tuflow_modules: list[str] = [
    "tuflow_culverts_merge",
    "tuflow_culverts_timeseries",
    "tuflow_logsummary",
    "tuflow_results_styling",
    "pomm_combine",
    "closure_durations",
]

for _mod in _tuflow_modules:
    module = import_module(f"ryan_library.orchestrators.tuflow.{_mod}")
    sys.modules[f"{__name__}.{_mod}"] = module
    globals()[_mod] = module

_gdal_module = import_module("ryan_library.orchestrators.gdal")
_tuflow_package = import_module("ryan_library.orchestrators.tuflow")
_rorb_package = import_module("ryan_library.orchestrators.rorb")

sys.modules[f"{__name__}.gdal"] = _gdal_module
sys.modules[f"{__name__}.tuflow"] = _tuflow_package
sys.modules[f"{__name__}.rorb"] = _rorb_package
sys.modules[f"{__name__}.RORB"] = _rorb_package

globals()["gdal"] = _gdal_module
globals()["tuflow"] = _tuflow_package
globals()["rorb"] = _rorb_package
globals()["RORB"] = _rorb_package

__all__: list[str] = ["gdal", "tuflow", "rorb", "RORB", *_tuflow_modules]
