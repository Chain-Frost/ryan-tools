# ryan_library/processors/tuflow/other_processors/ChanProcessor.py

__lazy_modules__ = ["pandas"]

import pandas as pd
from loguru import logger

from ..base_processor import ProcessorStatus
from ..max_data_processor import MaxDataProcessor


class ChanProcessor(MaxDataProcessor):
    """Processor for '_1d_Chan.csv' files."""

    def process(self) -> None:
        """Process the '_1d_Chan.csv' file and return a cleaned DataFrame.

        Returns:
            pd.DataFrame: Processed Chan data.
        """
        logger.info(f"Starting processing of Chan file: {self.log_path}")

        try:
            status: ProcessorStatus = self.read_maximums_csv()

            if status != ProcessorStatus.SUCCESS:
                logger.error(f"Processing aborted for file: {self.log_path} due to previous errors.")
                self.df = pd.DataFrame()
                return

            # Calculate Height
            if "LBUS Obvert" in self.df.columns and "US Invert" in self.df.columns:
                self.df["Height"] = self.df["LBUS Obvert"] - self.df["US Invert"]
                logger.debug("Calculated 'Height' column.")
            else:
                logger.error(f"Required columns for calculating Height are missing in file {self.log_path}.")
                self.df = pd.DataFrame()
                return

            # Rename 'Channel' to 'Chan ID'
            if "Channel" in self.df.columns:
                self.df = self.df.rename(columns={"Channel": "Chan ID"})
                logger.debug("Renamed 'Channel' to 'Chan ID'.")
            else:
                logger.error(f"'Channel' column is missing in file {self.log_path}.")
                self.df = pd.DataFrame()
                return

            # Rename 'LBUS Obvert' to 'US Obvert'
            # We already checked for existence of 'LBUS Obvert' above
            self.df = self.df.rename(columns={"LBUS Obvert": "US Obvert"})
            logger.debug("Renamed 'LBUS Obvert' to 'US Obvert'.")

            self.apply_entity_filter()
            # Proceed with common processing steps from BaseProcessor
            self.add_common_columns()
            self.apply_output_transformations()

            # Validate data
            if not self.validate_data():
                logger.error(f"{self.file_name}: Data validation failed.")
                self.df = pd.DataFrame()
                return

            self.processed = True
            logger.info(f"Completed processing of Chan file: {self.log_path}")

            return

        except Exception as e:
            logger.error(f"Failed to process Chan file {self.log_path}: {e}")
            self.df = pd.DataFrame()
            return
