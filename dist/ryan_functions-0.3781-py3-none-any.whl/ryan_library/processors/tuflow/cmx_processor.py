# ryan_library/processors/tuflow/cmx_processor.py

import pandas as pd
from loguru import logger
from pathlib import Path
from .base_processor import BaseProcessor


class CmxProcessor(BaseProcessor):
    """
    Processor for '_1d_Cmx.csv' files.
    """

    def process(self) -> pd.DataFrame:
        """
        Process the '_1d_Cmx.csv' file and return a cleaned DataFrame.

        Returns:
            pd.DataFrame: Processed CMX data.
        """
        logger.info(f"Starting processing of CMX file: {self.file_path}")

        # Read the CSV using the dedicated method
        df, status = self.read_maximums_csv()

        if status != 0:
            # If there was an error, set self.df to empty and return
            logger.error(
                f"Processing aborted for file: {self.file_path} due to previous errors."
            )
            self.df = pd.DataFrame()
            return self.df

        # Reshape the DataFrame to have separate rows for Qmax and Vmax
        self.df = self.reshape_cmx_data()

        if self.df.empty:
            logger.error(f"{self.file_name}: Reshaping resulted in an empty DataFrame.")
            return self.df

        # Apply output transformations (data type assignments)
        try:
            self.apply_output_transformations()
        except Exception as e:
            logger.error(
                f"Error applying output transformations for file {self.file_path}: {e}"
            )
            self.df = pd.DataFrame()
            return self.df

        # Add common columns (internalName, rel_path, etc.)
        self.add_common_columns()

        # Apply data types to additional columns
        try:
            self.apply_datatypes_to_df()
        except Exception as e:
            logger.error(
                f"Error applying additional datatypes for file {self.file_path}: {e}"
            )
            self.df = pd.DataFrame()
            return self.df

        # Validate data
        if not self.validate_data():
            logger.error(f"{self.file_name}: Data validation failed.")
            self.df = pd.DataFrame()
            return self.df

        self.processed = True
        logger.info(f"Completed processing of CMX file: {self.file_path}")

        return self.df

    def reshape_cmx_data(self) -> pd.DataFrame:
        """
        Reshape the CMX DataFrame to separate Qmax and Vmax entries using utility functions.

        Returns:
            pd.DataFrame: Reshaped DataFrame.
        """
        logger.debug(f"{self.file_name}: Starting reshaping of CMX data.")

        try:
            metric_columns = {
                "Time Qmax": "Time",
                "Qmax": "Q",
                "Time Vmax": "Time",
                "Vmax": "V",
            }
            new_columns_q = {"V": pd.NA}
            new_columns_v = {"Q": pd.NA}

            q_df = self.separate_metrics(
                metric_columns={"Time Qmax": "Time", "Qmax": "Q"},
                new_columns=new_columns_q,
            )

            v_df = self.separate_metrics(
                metric_columns={"Time Vmax": "Time", "Vmax": "V"},
                new_columns=new_columns_v,
            )

            cleaned_df = pd.concat([q_df, v_df], ignore_index=True)
            logger.debug(
                f"{self.file_name}: Concatenated DataFrame:\n{cleaned_df.head()}"
            )

            # Sort and assign
            cleaned_df.sort_values(by=["Chan ID", "Time"], inplace=True)
            self.df = cleaned_df

        except KeyError as e:
            logger.error(
                f"Missing expected columns during reshaping for file {self.file_path}: {e}"
            )
            return pd.DataFrame()
        except Exception as e:
            logger.error(f"{self.file_name}: Error during reshaping: {e}")
            return pd.DataFrame()

        logger.debug(f"{self.file_name}: Cleaned DataFrame head:\n{self.df.head()}")

        return self.df
