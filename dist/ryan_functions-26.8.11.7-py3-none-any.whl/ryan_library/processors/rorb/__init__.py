# Init for RORB processors
