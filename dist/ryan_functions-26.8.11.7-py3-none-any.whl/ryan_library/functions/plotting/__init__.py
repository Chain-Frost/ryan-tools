# Init for plotting functions
