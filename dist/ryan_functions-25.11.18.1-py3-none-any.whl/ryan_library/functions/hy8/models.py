"""Dataclasses and adapters for HY-8 conversion inputs and options."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping

from loguru import logger

from run_hy8 import CulvertMaterial, CulvertShape, FlowDefinition, UnitSystem

__all__: list[str] = ["Hy8CulvertInput", "Hy8CulvertOptions", "CulvertMaximumRecord"]


def _empty_raw_mapping() -> dict[str, Any]:
    return {}


def _default_shape_map() -> dict[str, CulvertShape]:
    return {"C": CulvertShape.CIRCLE, "R": CulvertShape.BOX}


def _default_material_map() -> dict[str, CulvertMaterial]:
    return {
        "R": CulvertMaterial.CONCRETE,
        "C": CulvertMaterial.CORRUGATED_STEEL,
    }


def _coerce_float(value: Any) -> float | None:
    if value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if math.isnan(number):
        return None
    return number


def _coerce_string(value: Any) -> str:
    if value is None:
        return ""
    text: str = str(value).strip()
    return text


def _compose_label(internal_name: str, chan_id: str, row_index: int | str | None) -> str:
    parts: list[str] = []
    if internal_name:
        parts.append(internal_name)
    if chan_id:
        parts.append(chan_id)
    if row_index is not None:
        parts.append(f"row={row_index}")
    if not parts:
        return "unknown culvert"
    return " / ".join(parts)


@dataclass(slots=True)
class Hy8CulvertOptions:
    """Configuration controlling how structured culvert data map to HY-8 models."""

    units: UnitSystem = UnitSystem.SI
    default_material: CulvertMaterial = CulvertMaterial.CONCRETE
    material_by_flag: dict[str, CulvertMaterial] = field(default_factory=_default_material_map)
    shape_by_flag: dict[str, CulvertShape] = field(default_factory=_default_shape_map)
    default_number_of_barrels: int = 1
    roadway_width_multiplier: float = 6.0
    minimum_roadway_width: float = 5.0
    roadway_crest_offset: float = 0.5
    tailwater_minimum_gap: float = 0.05
    flow_minimum_factor: float = 0.9
    flow_maximum_factor: float = 1.1
    minimum_flow_cms: float = 0.005
    crossing_name_template: str = "{internal}_{chan}"
    flow_builder: Callable[["Hy8CulvertInput", "Hy8CulvertOptions"], FlowDefinition] | None = None
    roadway_width_builder: Callable[["Hy8CulvertInput", "Hy8CulvertOptions"], float] | None = None
    roadway_crest_builder: Callable[["Hy8CulvertInput", "Hy8CulvertOptions"], float] | None = None
    barrel_count_builder: Callable[["Hy8CulvertInput", "Hy8CulvertOptions"], int] | None = None
    default_inlet_type: int = 1
    default_inlet_edge_type: int = 0
    default_inlet_edge_type71: int = 0
    default_improved_inlet_edge_type: int = 0


@dataclass(slots=True)
class Hy8CulvertInput:
    """Structured culvert description used by the generic HY-8 builders."""

    identifier: str
    flow_q: float
    ds_headwater: float
    ds_invert: float
    us_invert: float
    height: float
    length: float
    chan_id: str = ""
    internal_name: str = ""
    flag: str = ""
    us_headwater: float | None = None
    us_obvert: float | None = None
    ds_obvert: float | None = None
    mannings_n: float | None = None
    slope_percent: float | None = None
    blockage_percent: float | None = None
    area_culv: float | None = None
    notes: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=_empty_raw_mapping)


@dataclass(slots=True)
class CulvertMaximumRecord:
    """Strongly-typed view over the culvert maximum export inputs."""

    row_index: int | str | None
    trim_runcode: str
    internal_name: str
    chan_id: str
    flow_q: float
    ds_headwater: float
    ds_invert: float
    us_invert: float
    height: float
    length: float
    flag: str
    velocity: float | None = None
    us_headwater: float | None = None
    us_obvert: float | None = None
    ds_obvert: float | None = None
    mannings_n: float | None = None
    slope_percent: float | None = None
    blockage_percent: float | None = None
    area_culv: float | None = None
    raw: Mapping[str, Any] = field(default_factory=_empty_raw_mapping)

    @classmethod
    def from_mapping(cls, row: Mapping[str, Any], *, row_index: int | str | None) -> "CulvertMaximumRecord | None":
        trim_runcode: str = _coerce_string(row.get("trim_runcode"))
        internal_name: str = _coerce_string(row.get("internalName"))
        chan_id: str = _coerce_string(row.get("Chan ID"))
        q: float | None = _coerce_float(row.get("Q"))
        ds_headwater: float | None = _coerce_float(row.get("DS_h"))
        ds_invert: float | None = _coerce_float(row.get("DS Invert"))
        us_invert: float | None = _coerce_float(row.get("US Invert"))
        height: float | None = _coerce_float(row.get("Height"))
        length: float = _coerce_float(row.get("Length")) or 0.0
        flag: str = _coerce_string(row.get("Flags")).upper()
        label: str = _compose_label(internal_name, chan_id, row_index)

        missing: list[str] = []
        if q is None or q <= 0:
            missing.append("Q")
        if ds_headwater is None:
            missing.append("DS_h")
        if ds_invert is None:
            missing.append("DS Invert")
        if us_invert is None:
            missing.append("US Invert")
        if height is None or height <= 0:
            missing.append("Height")
        if missing:
            logger.warning("Skipping %s because %s are missing.", label, ", ".join(missing))
            return None

        assert q is not None
        assert ds_headwater is not None
        assert ds_invert is not None
        assert us_invert is not None
        assert height is not None

        ds_obvert: float | None = _coerce_float(row.get("DS Obvert"))
        us_obvert: float | None = _coerce_float(row.get("US Obvert"))
        us_headwater: float | None = _coerce_float(row.get("US_h"))
        velocity: float | None = _coerce_float(row.get("V"))
        slope_percent: float | None = _coerce_float(row.get("pSlope"))
        blockage_percent: float | None = _coerce_float(row.get("pBlockage"))
        mannings_n: float | None = _coerce_float(row.get("n or Cd"))
        area_culv: float | None = _coerce_float(row.get("Area_Culv")) or _coerce_float(row.get("area_culv"))
        normalized_length: float = length if length > 0 else height
        raw_mapping: dict[str, Any] = {str(key): value for key, value in row.items()}

        return cls(
            row_index=row_index,
            trim_runcode=trim_runcode,
            internal_name=internal_name,
            chan_id=chan_id,
            flow_q=q,
            ds_headwater=ds_headwater,
            ds_invert=ds_invert,
            us_invert=us_invert,
            height=height,
            length=normalized_length,
            flag=flag,
            velocity=velocity,
            us_headwater=us_headwater,
            us_obvert=us_obvert,
            ds_obvert=ds_obvert,
            mannings_n=mannings_n,
            slope_percent=slope_percent,
            blockage_percent=blockage_percent,
            area_culv=area_culv,
            raw=raw_mapping,
        )

    @property
    def identifier(self) -> str:
        label: str = _compose_label(self.internal_name, self.chan_id, self.row_index)
        if self.trim_runcode:
            return f"{label} ({self.trim_runcode})"
        return label

    def to_culvert_input(self) -> Hy8CulvertInput:
        return Hy8CulvertInput(
            identifier=self.identifier,
            flow_q=self.flow_q,
            ds_headwater=self.ds_headwater,
            ds_invert=self.ds_invert,
            us_invert=self.us_invert,
            height=self.height,
            length=self.length,
            chan_id=self.chan_id,
            internal_name=self.internal_name,
            flag=self.flag,
            us_headwater=self.us_headwater,
            us_obvert=self.us_obvert,
            ds_obvert=self.ds_obvert,
            mannings_n=self.mannings_n,
            slope_percent=self.slope_percent,
            blockage_percent=self.blockage_percent,
            area_culv=self.area_culv,
            notes=_build_tuflow_notes(self),
            metadata=self.raw,
        )


def _build_tuflow_notes(record: CulvertMaximumRecord) -> str:
    entries: list[str] = []
    if record.trim_runcode:
        entries.append(f"run={record.trim_runcode}")
    if record.internal_name:
        entries.append(f"internalName={record.internal_name}")
    if record.chan_id:
        entries.append(f"chan={record.chan_id}")
    if record.slope_percent is not None:
        entries.append(f"pSlope={record.slope_percent}")
    if record.blockage_percent is not None:
        entries.append(f"pBlockage={record.blockage_percent}")
    if not entries:
        return record.identifier
    return "; ".join(entries)
