"""High-level utilities that build HY-8 objects from TUFLOW maximums."""

from __future__ import annotations

from typing import Any, Sequence, cast

from loguru import logger
from pandas import DataFrame

from run_hy8 import CulvertCrossing, Hy8Project

from .crossings import build_crossing
from .models import CulvertMaximumRecord, Hy8CulvertInput, Hy8CulvertOptions

__all__: list[str] = [
    "maximums_dataframe_to_inputs",
    "maximums_dataframe_to_crossings",
    "maximums_dataframe_to_project",
]


def maximums_dataframe_to_inputs(
    maximums: DataFrame,
) -> list[Hy8CulvertInput]:
    """Convert the Maximums sheet into structured culvert inputs."""

    if maximums.empty:
        return []

    raw_rows = cast(
        list[dict[str, Any]],
        maximums.to_dict(orient="records"),  # pyright: ignore[reportUnknownMemberType]
    )
    indexes: Sequence[int | str] = list(maximums.index)
    inputs: list[Hy8CulvertInput] = []
    for idx, raw_row in zip(indexes, raw_rows):
        record: CulvertMaximumRecord | None = CulvertMaximumRecord.from_mapping(raw_row, row_index=idx)
        if record is None:
            continue
        inputs.append(record.to_culvert_input())
    logger.info("Parsed %d structured culvert rows from %d raw rows.", len(inputs), len(raw_rows))
    return inputs


def maximums_dataframe_to_crossings(
    maximums: DataFrame,
    *,
    options: Hy8CulvertOptions | None = None,
) -> list[CulvertCrossing]:
    """Convert the Maximums sheet into HY-8 crossings."""

    cfg: Hy8CulvertOptions = options or Hy8CulvertOptions()
    inputs: list[Hy8CulvertInput] = maximums_dataframe_to_inputs(maximums)
    crossings: list[CulvertCrossing] = [build_crossing(culvert, options=cfg) for culvert in inputs]
    logger.info("Built %d HY-8 crossings from %d structured rows.", len(crossings), len(inputs))
    return crossings


def maximums_dataframe_to_project(
    maximums: DataFrame,
    *,
    project_title: str,
    designer: str = "",
    project_notes: str | None = None,
    options: Hy8CulvertOptions | None = None,
) -> Hy8Project:
    """Create a Hy8Project populated with crossings from the provided DataFrame."""

    cfg: Hy8CulvertOptions = options or Hy8CulvertOptions()
    project = Hy8Project(title=project_title, designer=designer, units=cfg.units, notes=project_notes or "")
    for crossing in maximums_dataframe_to_crossings(maximums=maximums, options=cfg):
        project.crossings.append(crossing)
    return project
