"""Builders that convert structured culvert data into HY-8 crossings."""

from __future__ import annotations

import math
import re
from typing import Any, cast

from loguru import logger

from run_hy8 import (
    CulvertBarrel,
    CulvertCrossing,
    CulvertMaterial,
    CulvertShape,
    FlowDefinition,
    FlowMethod,
    RoadwaySurface,
    TailwaterDefinition,
)

from .models import Hy8CulvertInput, Hy8CulvertOptions

__all__ = ["build_crossing"]

_SLUG_PATTERN: re.Pattern[str] = re.compile(pattern=r"[^A-Za-z0-9]+")


def build_crossing(
    culvert: Hy8CulvertInput,
    *,
    options: Hy8CulvertOptions | None = None,
) -> CulvertCrossing:
    """Generate a single CulvertCrossing from structured culvert inputs."""

    cfg: Hy8CulvertOptions = options or Hy8CulvertOptions()
    name: str = _resolve_crossing_name(culvert, cfg)
    crossing = CulvertCrossing(name=name)
    crossing.notes = culvert.notes or culvert.identifier
    crossing.flow = _build_flow(culvert, cfg)
    crossing.tailwater = _build_tailwater(culvert, cfg)
    _configure_roadway(crossing, culvert, cfg)
    crossing.culverts = [_build_barrel(culvert, cfg)]
    return crossing


def _resolve_crossing_name(culvert: Hy8CulvertInput, options: Hy8CulvertOptions) -> str:
    internal_slug: str = _slugify(culvert.internal_name or culvert.identifier or "Scenario")
    chan_slug: str = _slugify(culvert.chan_id or "CHAN")
    template: str = options.crossing_name_template or "{internal}_{chan}"
    try:
        raw_name = template.format(internal=internal_slug, chan=chan_slug, record=culvert)
    except (KeyError, ValueError):
        raw_name = f"{internal_slug}_{chan_slug}"
    return _slugify(raw_name, fallback=internal_slug)


def _slugify(value: str, *, fallback: str = "Crossing") -> str:
    candidate: str = _SLUG_PATTERN.sub("_", value).strip("_")
    return candidate or fallback


def _build_flow(culvert: Hy8CulvertInput, options: Hy8CulvertOptions) -> FlowDefinition:
    if options.flow_builder is not None:
        return options.flow_builder(culvert, options)

    flow = FlowDefinition(method=FlowMethod.MIN_DESIGN_MAX)
    design: float = max(options.minimum_flow_cms, culvert.flow_q)
    minimum: float = max(options.minimum_flow_cms, design * options.flow_minimum_factor)
    maximum: float = max(design + options.minimum_flow_cms, design * options.flow_maximum_factor)
    if minimum >= design:
        design = minimum + options.minimum_flow_cms
    if design >= maximum:
        maximum = design + options.minimum_flow_cms
    flow.minimum = minimum
    flow.design = design
    flow.maximum = maximum
    return flow


def _build_tailwater(culvert: Hy8CulvertInput, options: Hy8CulvertOptions) -> TailwaterDefinition:
    tailwater = TailwaterDefinition()
    tailwater.constant_elevation = culvert.ds_headwater
    tailwater.invert_elevation = min(
        culvert.ds_invert,
        tailwater.constant_elevation - options.tailwater_minimum_gap,
    )
    if tailwater.constant_elevation <= tailwater.invert_elevation:
        tailwater.constant_elevation = culvert.ds_invert + options.tailwater_minimum_gap
        tailwater.invert_elevation = culvert.ds_invert
    return tailwater


def _configure_roadway(
    crossing: CulvertCrossing,
    culvert: Hy8CulvertInput,
    options: Hy8CulvertOptions,
) -> None:
    width: float = (
        options.roadway_width_builder(culvert, options)
        if options.roadway_width_builder
        else _default_roadway_width(culvert, options)
    )
    crest: float = (
        options.roadway_crest_builder(culvert, options)
        if options.roadway_crest_builder
        else _default_roadway_crest(culvert, options)
    )
    width = max(options.minimum_roadway_width, width)
    crossing.roadway.width = width
    crossing.roadway.surface = RoadwaySurface.PAVED
    half_width: float = width / 2.0
    crossing.roadway.stations = [-half_width, 0.0, half_width]
    crossing.roadway.elevations = [crest, crest, crest]


def _default_roadway_width(culvert: Hy8CulvertInput, options: Hy8CulvertOptions) -> float:
    return max(options.minimum_roadway_width, culvert.height * options.roadway_width_multiplier)


def _default_roadway_crest(culvert: Hy8CulvertInput, options: Hy8CulvertOptions) -> float:
    candidates: list[float] = []
    for candidate in (
        culvert.us_headwater,
        culvert.ds_headwater,
        culvert.us_obvert or (culvert.us_invert + culvert.height),
        culvert.ds_obvert or (culvert.ds_invert + culvert.height),
    ):
        if candidate is not None:
            candidates.append(candidate)
    base: float = max(candidates) if candidates else culvert.ds_headwater
    return base + max(0.0, options.roadway_crest_offset)


def _build_barrel(culvert: Hy8CulvertInput, options: Hy8CulvertOptions) -> CulvertBarrel:
    barrel = CulvertBarrel(name=culvert.chan_id or "Barrel")
    barrel.material = _resolve_material(culvert, options)
    barrel.shape = _infer_shape(culvert, options)
    span, rise = _resolve_span_rise(culvert, barrel.shape)
    barrel.span = span
    barrel.rise = rise
    barrel.number_of_barrels = _resolve_barrel_count(culvert, options)
    barrel.inlet_invert_station = 0.0
    barrel.outlet_invert_station = culvert.length
    barrel.inlet_invert_elevation = culvert.us_invert
    barrel.outlet_invert_elevation = culvert.ds_invert
    if culvert.mannings_n and culvert.mannings_n > 0:
        barrel.manning_n_top = culvert.mannings_n
        barrel.manning_n_bottom = culvert.mannings_n
    barrel.inlet_type = cast(Any, options.default_inlet_type)
    barrel.inlet_edge_type = cast(Any, options.default_inlet_edge_type)
    barrel.inlet_edge_type71 = cast(Any, options.default_inlet_edge_type71)
    barrel.improved_inlet_edge_type = cast(Any, options.default_improved_inlet_edge_type)
    return barrel


def _infer_shape(culvert: Hy8CulvertInput, options: Hy8CulvertOptions) -> CulvertShape:
    flag: str = culvert.flag
    if flag and flag in options.shape_by_flag:
        return options.shape_by_flag[flag]
    chan_hint: str = culvert.chan_id.split("_")[-1].upper() if culvert.chan_id else ""
    if chan_hint in options.shape_by_flag:
        return options.shape_by_flag[chan_hint]
    return CulvertShape.CIRCLE


def _resolve_span_rise(culvert: Hy8CulvertInput, shape: CulvertShape) -> tuple[float, float]:
    if shape is CulvertShape.CIRCLE:
        return culvert.height, culvert.height
    # Without a width column we assume a square box and flag for follow-up in notes.
    return culvert.height, culvert.height


def _resolve_barrel_count(culvert: Hy8CulvertInput, options: Hy8CulvertOptions) -> int:
    if options.barrel_count_builder is not None:
        count: int = options.barrel_count_builder(culvert, options)
        return max(1, count)
    if culvert.area_culv and culvert.area_culv > 0:
        single_area: float = _culvert_cross_section_area(culvert, options)
        if single_area > 0:
            derived: int = max(1, round(culvert.area_culv / single_area))
            logger.debug(
                "Derived %d barrels from Area_Culv %.3f m2 (single %.3f m2).",
                derived,
                culvert.area_culv,
                single_area,
            )
            return derived
        logger.debug(
            "Area-based barrel estimate not implemented for flag '%s'; falling back to defaults.",
            culvert.flag,
        )
    return max(1, options.default_number_of_barrels)


def _culvert_cross_section_area(culvert: Hy8CulvertInput, options: Hy8CulvertOptions) -> float:
    shape: CulvertShape = _infer_shape(culvert, options)
    if shape is CulvertShape.CIRCLE:
        return math.pi * (culvert.height / 2.0) ** 2
    # TODO: support rectangular culverts once Area_Culv width inference is implemented.
    return 0.0


def _resolve_material(culvert: Hy8CulvertInput, options: Hy8CulvertOptions) -> CulvertMaterial:
    flag: str = culvert.flag
    if flag and flag in options.material_by_flag:
        return options.material_by_flag[flag]
    return options.default_material
