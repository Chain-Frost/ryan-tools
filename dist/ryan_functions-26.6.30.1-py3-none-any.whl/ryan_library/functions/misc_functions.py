# ryan_library/functions/misc_functions.py

from datetime import datetime
import multiprocessing
import pandas as pd
import logging
from loguru import logger
from typing import Literal, TypedDict
from pathlib import Path
from importlib import metadata
import re
from openpyxl.utils import get_column_letter
from openpyxl import Workbook
from openpyxl.worksheet.worksheet import Worksheet
from openpyxl.utils.exceptions import InvalidFileException
from ryan_library.functions.logging_helpers import setup_logging as new_setup_logging


def get_tools_version(package: str = "ryan_functions") -> str:
    """Return the installed version of ``package`` if available."""
    try:
        return metadata.version(distribution_name=package)
    except metadata.PackageNotFoundError:
        return "unknown"


# Deprecated setup_logging function
def setup_logging(
    log_level: int = logging.INFO,
    log_file: str | None = None,
    max_bytes: int = 10**6,  # 1 MB
    backup_count: int = 5,
    use_rotating_file: bool = False,
    enable_color: bool = True,
) -> None:
    print("This is using a deprecated logging procedure")
    new_setup_logging(
        log_level=log_level,
        log_file=log_file,
        max_bytes=max_bytes,
        backup_count=backup_count,
        use_rotating_file=use_rotating_file,
        enable_color=enable_color,
    )


def calculate_pool_size(num_files: int) -> int:
    """Calculate the optimal pool size based on the number of files and CPU cores.
    Args:
        num_files (int): Number of files to process.
    Returns:
        int: Number of threads to use."""
    splits: int = max(num_files // 3, 1)
    available_cores: int = min(multiprocessing.cpu_count(), 20)
    calc_threads: int = min(available_cores - 1, splits) if available_cores > 1 else 1
    logging.info(f"Processing threads: {calc_threads}")
    return calc_threads


def split_strings(input_str: str | list[str]) -> list[str]:
    """Split input string(s) by whitespace into a flat list of strings.
    Args:
        input_str (str | list[str]): A string or list of strings to split.
    Returns:
        list[str]: A flat list of split strings."""
    if isinstance(input_str, str):
        input_list: list[str] = [input_str]
    else:  # input is already a list
        input_list = input_str

    # Split each string by whitespace and flatten the list
    split_list: list[str] = []
    for item in input_list:
        split_list.extend(item.split())

    return split_list


def split_strings_in_dict(params_dict: dict[str, list[str]]) -> dict[str, list[str]]:
    """Apply split_strings to each list of strings in the dictionary.
    Args:
        params_dict (dict[str, list[str]]): Dictionary with string lists to split.
    Returns:
        dict[str, list[str]]: Dictionary with split string lists."""
    for key, value in params_dict.items():
        # Use split_strings to handle both string and list of strings cases
        params_dict[key] = split_strings(input_str=value)
    return params_dict


class ExportContent(TypedDict):
    dataframes: list[pd.DataFrame]
    sheets: list[str]


class ExcelExporter:
    """A utility class for exporting pandas DataFrames to Excel files.

    Methods:
        export_dataframes: Export multiple DataFrames to Excel with optional column widths.
        save_to_excel: Export a single DataFrame to Excel with optional column widths.
        calculate_column_widths: Calculate optimal column widths based on data.
        set_column_widths: Apply specific column widths to a worksheet.
        auto_adjust_column_widths: Automatically adjust column widths based on data."""

    MAX_EXCEL_ROWS: int = 1_048_576
    MAX_EXCEL_COLUMNS: int = 16_384
    DEFAULT_NARROW_WIDTH: float = 8.43  # ~64px (Excel default width)
    DEFAULT_NARROW_COLUMNS: tuple[str, ...] = ("file", "rel_directory", "rel_path", "directory_path", "path")

    def export_dataframes(
        self,
        export_dict: dict[str, ExportContent],
        output_directory: Path | None = None,
        column_widths: dict[str, dict[str, float]] | None = None,
        auto_adjust_width: bool = True,
        file_name: str | None = None,
        *,
        export_mode: Literal["excel", "parquet", "both"] = "excel",
        parquet_compression: str = "gzip",
    ) -> None:
        """Export multiple DataFrames to Excel files with optional column widths.
        Args:
            export_dict (dict[str, ExportContent]):
                A dictionary where each key is a base file name and each value contains:
                    - "dataframes": list of DataFrames
                    - "sheets": list of corresponding sheet names
            output_directory (Path | None, optional):
                The directory where the Excel files will be saved.
                Defaults to the current working directory.
            column_widths (dict[str, dict[str, float]] | None, optional):
                A dictionary where keys are sheet names and values are dictionaries
                mapping column names to their desired widths.
                Example:
                    {
                        "Sheet1": {"Name": 20, "Age": 10},
                        "Sheet2": {"Email": 30}
                    }
            auto_adjust_width (bool, optional):
                If set to True, automatically adjusts the column widths based on the
                maximum length of the data in each column. Defaults to True.
            file_name (str | None, optional):
                Explicit workbook name to use when exporting a single entry from
                ``export_dict``. When provided, the auto-generated timestamp prefix is
                skipped and ``file_name`` is written exactly (``.xlsx`` appended when
                missing).
            export_mode (Literal["excel", "parquet", "both"], optional):
                Controls which artefacts are produced:
                  * "excel" (default) writes only Excel files (with automatic Parquet/CSV
                    fallback when Excel limits are exceeded).
                  * "parquet" skips Excel entirely and writes Parquet files matching the
                    Excel naming scheme.
                  * "both" writes Excel files (subject to the standard fallback) and also
                    emits companion Parquet files.
            parquet_compression (str, optional):
                Compression codec passed to pandas whenever Parquet files are written.
                Defaults to ``"gzip"``.
        Raises:
            ValueError: If the number of DataFrames doesn't match the number of sheets.
            InvalidFileException: If there's an issue with writing the Excel file.
        Example:
            export_dict = {
                "Report": {
                    "dataframes": [df1, df2],
                    "sheets": ["Summary", "Details"]
                },
                "AnotherReport": {
                    "dataframes": [df3],
                    "sheets": ["Data"]
                }
            }
            ExcelExporter().export_dataframes(export_dict, output_directory=Path("exports"))
        """
        datetime_string: str = datetime.now().strftime(format="%Y%m%d-%H%M")
        normalized_mode: str = export_mode.lower()
        valid_modes: set[str] = {"excel", "parquet", "both"}
        if normalized_mode not in valid_modes:
            raise ValueError(f"Invalid export_mode '{export_mode}'. Expected one of {sorted(valid_modes)}.")

        if file_name is not None and len(export_dict) != 1:
            raise ValueError("'file_name' can only be provided when exporting a single workbook.")

        for export_key, content in export_dict.items():
            dataframes: list[pd.DataFrame] = content.get("dataframes", [])
            sheets: list[str] = content.get("sheets", [])

            if len(dataframes) != len(sheets):
                file_label: str = file_name if file_name is not None else export_key
                raise ValueError(
                    (
                        f"For file '{file_label}', the number of dataframes ({len(dataframes)}) and sheets "
                        f"({len(sheets)}) must match."
                    )
                )

            export_stem: str = self._resolve_export_stem(
                datetime_string=datetime_string, export_key=export_key, file_name=file_name
            )

            if normalized_mode == "parquet":
                self._export_as_parquet_only(
                    export_stem=export_stem,
                    dataframes=dataframes,
                    sheets=sheets,
                    output_directory=output_directory,
                    compression=parquet_compression,
                )
                continue

            if self._exceeds_excel_limits(dataframes=dataframes):
                logger.warning(
                    f"Data for '{export_stem}' exceeds Excel size limits. Exporting to Parquet and CSV instead."
                )
                self._export_as_parquet_and_csv(
                    export_stem=export_stem,
                    dataframes=dataframes,
                    sheets=sheets,
                    output_directory=output_directory,
                    compression=parquet_compression,
                )
                continue

            # Determine the export path
            if file_name is not None:
                export_filename = file_name if file_name.lower().endswith(".xlsx") else f"{file_name}.xlsx"
            else:
                export_filename = f"{export_stem}.xlsx"
            export_path: Path = (
                (output_directory / export_filename) if output_directory else Path(export_filename)  # Defaults to CWD
            )

            # Ensure the output directory exists
            if output_directory:
                export_path.parent.mkdir(parents=True, exist_ok=True)

            logger.info(f"Exporting to {export_path}")

            try:
                with pd.ExcelWriter(path=export_path, engine="openpyxl") as writer:
                    writer.book.properties.creator = f"ryan-tools {get_tools_version()}"
                    for df, sheet in zip(dataframes, sheets):
                        # Check for unique column names
                        if not df.columns.is_unique:
                            logger.error(
                                "Duplicate column names in DataFrame for sheet '{}'. "
                                "Ensure all column names are unique.",
                                sheet,
                            )
                            raise ValueError(f"Duplicate column names found in sheet '{sheet}'.")

                        df.to_excel(
                            excel_writer=writer,
                            sheet_name=sheet,
                            merge_cells=False,
                            index=False,
                        )

                        # Access the worksheet
                        workbook: Workbook = writer.book
                        worksheet: Worksheet = writer.sheets[sheet]

                        # Automatically adjust column widths if enabled
                        if auto_adjust_width:
                            dynamic_widths: dict[str, float] = self.calculate_column_widths(df=df)
                            self.auto_adjust_column_widths(worksheet=worksheet, dynamic_widths=dynamic_widths)
                            self._apply_default_column_widths(worksheet=worksheet, df=df, sheet_name=sheet)

                        # Apply specific column widths if provided
                        if column_widths and sheet in column_widths:
                            self.set_column_widths(
                                worksheet=worksheet,
                                df=df,
                                sheet_name=sheet,
                                column_widths=column_widths[sheet],
                            )

                logger.success(f"Finished exporting '{export_filename}' to '{export_path}'")
            except InvalidFileException as e:
                logger.error(f"Failed to write to '{export_path}': {e}")
                raise

            if normalized_mode == "both":
                self._export_as_parquet_only(
                    export_stem=export_stem,
                    dataframes=dataframes,
                    sheets=sheets,
                    output_directory=output_directory,
                    compression=parquet_compression,
                )

    def _exceeds_excel_limits(self, dataframes: list[pd.DataFrame]) -> bool:
        """Return True if any dataframe exceeds Excel's size limits."""

        for df in dataframes:
            num_data_rows: int = len(df.index)
            num_columns: int = len(df.columns)
            header_rows: int = df.columns.nlevels if num_columns > 0 else 0
            total_rows: int = num_data_rows + header_rows

            if total_rows > self.MAX_EXCEL_ROWS or num_columns > self.MAX_EXCEL_COLUMNS:
                logger.debug(
                    (
                        "Dataframe size rows={} (including {} header rows) columns={} exceeds Excel limits "
                        "(rows={}, columns={})."
                    ),
                    total_rows,
                    header_rows,
                    num_columns,
                    self.MAX_EXCEL_ROWS,
                    self.MAX_EXCEL_COLUMNS,
                )
                return True
        return False

    def _resolve_export_stem(self, *, datetime_string: str, export_key: str, file_name: str | None) -> str:
        """Return the base filename (without extension) for the current export."""

        if file_name:
            return file_name[:-5] if file_name.lower().endswith(".xlsx") else file_name
        return f"{datetime_string}_{export_key}"

    def _build_parquet_filename(self, base_filename: str, compression: str | None) -> str:
        """Return a parquet filename with an optional compression suffix."""

        if compression:
            suffix = compression.lower()
            if suffix == "gzip":
                return f"{base_filename}.parquet.gzip"
            return f"{base_filename}.parquet.{suffix}"
        return f"{base_filename}.parquet"

    def _write_parquet(
        self,
        *,
        df: pd.DataFrame,
        sheet: str,
        parquet_path: Path,
        export_label: str,
        compression: str | None,
    ) -> None:
        """Write a DataFrame to Parquet with consistent logging and error handling."""

        try:
            df.to_parquet(path=parquet_path, index=False, compression=compression)
            logger.info(f"Exported Parquet to {parquet_path}")
        except (ImportError, ValueError) as exc:
            message: str = (
                "Unable to export Parquet for "
                f"'{export_label}' sheet '{sheet}': {exc}. Install pyarrow or fastparquet."
            )
            logger.error(message)
            print(message)
        except Exception as exc:  # pragma: no cover - unforeseen errors should be logged
            logger.exception(f"Unexpected error during Parquet export for '{export_label}' sheet '{sheet}': {exc}")

    def _export_as_parquet_only(
        self,
        *,
        export_stem: str,
        dataframes: list[pd.DataFrame],
        sheets: list[str],
        output_directory: Path | None,
        compression: str | None,
    ) -> None:
        """Export each DataFrame to a Parquet file sharing the Excel naming scheme."""

        export_targets: list[tuple[pd.DataFrame, str, Path]] = []
        for df, sheet in zip(dataframes, sheets):
            sanitized_sheet: str = self._sanitize_name(sheet)
            base_filename: str = f"{export_stem}_{sanitized_sheet}"
            parquet_filename: str = self._build_parquet_filename(base_filename, compression)
            parquet_path: Path = self._build_output_path(
                base_filename=parquet_filename, output_directory=output_directory
            )
            parquet_path.parent.mkdir(parents=True, exist_ok=True)
            export_targets.append((df, sheet, parquet_path))

        for df, sheet, parquet_path in export_targets:
            self._write_parquet(
                df=df,
                sheet=sheet,
                parquet_path=parquet_path,
                export_label=export_stem,
                compression=compression,
            )

    def _export_as_parquet_and_csv(
        self,
        *,
        export_stem: str,
        dataframes: list[pd.DataFrame],
        sheets: list[str],
        output_directory: Path | None,
        compression: str | None = None,
    ) -> None:
        """Export dataframes to Parquet and CSV files when Excel limits are exceeded."""

        export_targets: list[tuple[pd.DataFrame, str, Path, Path]] = []

        for df, sheet in zip(dataframes, sheets):
            sanitized_sheet: str = self._sanitize_name(sheet)
            base_filename: str = f"{export_stem}_{sanitized_sheet}"

            parquet_filename: str = self._build_parquet_filename(base_filename, compression)
            parquet_path: Path = self._build_output_path(
                base_filename=parquet_filename, output_directory=output_directory
            )
            csv_path: Path = self._build_output_path(
                base_filename=f"{base_filename}.csv", output_directory=output_directory
            )

            parquet_path.parent.mkdir(parents=True, exist_ok=True)
            export_targets.append((df, sheet, parquet_path, csv_path))

        for df, sheet, parquet_path, _ in export_targets:
            self._write_parquet(
                df=df,
                sheet=sheet,
                parquet_path=parquet_path,
                export_label=export_stem,
                compression=compression,
            )

        for df, sheet, _, csv_path in export_targets:
            df.to_csv(path_or_buf=csv_path, index=False)
            logger.info(f"Exported CSV to {csv_path}")

    def _build_output_path(self, base_filename: str, output_directory: Path | None) -> Path:
        """Create the full output path for a file name."""

        if output_directory is not None:
            return output_directory / base_filename
        return Path(base_filename)

    def _sanitize_name(self, value: str) -> str:
        """Return a filesystem-friendly version of the provided value."""

        sanitized: str = re.sub(pattern=r"[^A-Za-z0-9_-]+", repl="_", string=value).strip("_")
        return sanitized or "Sheet"

    def save_to_excel(
        self,
        data_frame: pd.DataFrame,
        file_name_prefix: str = "Export",
        sheet_name: str = "Export",
        output_directory: Path | None = None,
        column_widths: dict[str, float] | None = None,
        auto_adjust_width: bool = True,
        file_name: str | None = None,
        *,
        export_mode: Literal["excel", "parquet", "both"] = "excel",
        parquet_compression: str = "gzip",
    ) -> None:
        """Export a single DataFrame to an Excel file with a single sheet and optional column widths.

        Args:
            data_frame (pd.DataFrame): The DataFrame to export.
            file_name_prefix (str): Prefix for the resulting Excel filename.
            sheet_name (str): Name of the sheet in the Excel file.
            output_directory (Path | None, optional):
                The directory where the Excel file will be saved.
                Defaults to the current working directory.
            column_widths (dict[str, float] | None, optional):
                A dictionary mapping column names to their desired widths.
                Example:
                    {"Name": 20, "Age": 10}
            auto_adjust_width (bool, optional):
                If set to True, automatically adjusts the column widths based on the
                maximum length of the data in each column. Defaults to True.
            file_name (str | None, optional):
                Explicit file name to use for the exported workbook. When provided the
                timestamp-based prefix is skipped and ``file_name`` is written exactly as
                supplied (``.xlsx`` is appended automatically when missing).
            export_mode (Literal["excel", "parquet", "both"], optional):
                See :meth:`export_dataframes` for details.
            parquet_compression (str, optional):
                Compression codec to use when Parquet outputs are requested. Defaults to
                ``"gzip"``."""
        export_dict: dict[str, ExportContent] = {file_name_prefix: {"dataframes": [data_frame], "sheets": [sheet_name]}}

        # Prepare column_widths in the required format
        prepared_column_widths: dict[str, dict[str, float]] | None = (
            {sheet_name: column_widths} if column_widths else None
        )

        self.export_dataframes(
            export_dict=export_dict,
            output_directory=output_directory,
            column_widths=prepared_column_widths,
            auto_adjust_width=auto_adjust_width,
            file_name=file_name,
            export_mode=export_mode,
            parquet_compression=parquet_compression,
        )

    def calculate_column_widths(self, df: pd.DataFrame) -> dict[str, float]:
        """Calculate optimal column widths based on the maximum length of data in each column.

        Args:
            df (pd.DataFrame): The DataFrame for which to calculate column widths.

        Returns:
            dict[str, float]: A dictionary mapping column letters to their calculated widths.
        """
        column_widths: dict[str, float] = {
            get_column_letter(idx + 1): max(
                self._calculate_max_cell_length(series=df[col]),
                # Consider the column name length as well
                len(str(col)),
            )
            + 2  # Adding extra space
            for idx, col in enumerate(df.columns)
        }
        logger.debug("Calculated dynamic column widths: {}", column_widths)
        return column_widths

    def _calculate_max_cell_length(self, series: pd.Series) -> int:
        """Return the longest display length for a Series when exporting to Excel."""

        if series.empty:
            return 0

        max_length: int = 0
        for value in series.to_numpy(dtype=object, copy=False):
            value_length: int = len("" if pd.isna(value) else str(value))
            if value_length > max_length:
                max_length = value_length

        return max_length

    def set_column_widths(
        self,
        worksheet: Worksheet,
        df: pd.DataFrame,
        sheet_name: str,
        column_widths: dict[str, float],
    ) -> None:
        """Set specific column widths for a given worksheet based on provided configurations.
        Args:
            worksheet (Worksheet): The OpenPyXL worksheet object.
            df (pd.DataFrame): The pandas DataFrame containing the data.
            sheet_name (str): The name of the current sheet.
            column_widths (dict[str, float]):
                A dictionary mapping column names to their desired widths.
        Raises:
            TypeError: If column indices are not integers."""
        for col_name, width in column_widths.items():
            if col_name not in df.columns:
                logger.warning(f"Column '{col_name}' not found in sheet '{sheet_name}'. Skipping width setting.")
                continue

            try:

                col_idx = df.columns.get_loc(col_name)
                assert isinstance(col_idx, int), (
                    f"Expected integer column index for '{col_name}' in sheet '{sheet_name}', "
                    f"but got {type(col_idx).__name__}"
                )
                col_letter: str = get_column_letter(col_idx + 1)
                worksheet.column_dimensions[col_letter].width = width
                logger.debug(f"Set width for column '{col_name}' ({col_letter}) in sheet '{sheet_name}' to {width}.")
            except TypeError as e:
                logger.exception(f"TypeError when setting width for column '{col_name}' in sheet '{sheet_name}': {e}")
            except AssertionError as e:
                logger.exception(str(e))
            except Exception as e:
                logger.exception(
                    f"Unexpected error when setting width for column '{col_name}' in sheet '{sheet_name}': {e}"
                )

    def auto_adjust_column_widths(self, worksheet: Worksheet, dynamic_widths: dict[str, float]) -> None:
        """Automatically adjust column widths based on calculated dynamic widths.
        Args:
            worksheet (Worksheet): The OpenPyXL worksheet object.
            dynamic_widths (dict[str, float]): Calculated dynamic column widths."""
        for col_letter, width in dynamic_widths.items():
            current_width: float | None = worksheet.column_dimensions[col_letter].width
            if current_width is None or width > current_width:
                worksheet.column_dimensions[col_letter].width = width
                logger.debug(f"Auto-adjusted width for column '{col_letter}' to {width}.")

    def _apply_default_column_widths(self, worksheet: Worksheet, df: pd.DataFrame, sheet_name: str) -> None:
        """Apply hard-coded default widths to known columns after auto-sizing has run."""
        default_widths: dict[str, float] = {
            column_name: self.DEFAULT_NARROW_WIDTH
            for column_name in self.DEFAULT_NARROW_COLUMNS
            if column_name in df.columns
        }
        if not default_widths:
            return

        self.set_column_widths(worksheet=worksheet, df=df, sheet_name=sheet_name, column_widths=default_widths)


# Backwards compatibility functions:
def export_dataframes(export_dict: dict[str, ExportContent], output_directory: Path | None = None) -> None:
    """Backwards-compatible function that delegates to ExcelExporter.
    Args:
        export_dict (dict[str, ExportContent]):
            Dictionary containing export information.
        output_directory (Path, optional):
            Directory to save the exported Excel files.
            Defaults to the current working directory."""
    ExcelExporter().export_dataframes(export_dict=export_dict, output_directory=output_directory)


def save_to_excel(
    data_frame: pd.DataFrame,
    file_name_prefix: str = "Export",
    sheet_name: str = "Export",
    output_directory: Path | None = None,
    *,
    file_name: str | None = None,
) -> None:
    """Backwards-compatible function that delegates to ExcelExporter.
    Args:
        data_frame (pd.DataFrame): The DataFrame to export.
        file_name_prefix (str): Prefix for the resulting Excel filename.
        sheet_name (str): Name of the sheet in the Excel file.
        output_directory (Path, optional):
            Directory to save the exported Excel file.
            Defaults to the current working directory."""
    ExcelExporter().save_to_excel(
        data_frame=data_frame,
        file_name_prefix=file_name_prefix,
        sheet_name=sheet_name,
        output_directory=output_directory,
        column_widths=None,
        auto_adjust_width=True,
        file_name=file_name,
    )
