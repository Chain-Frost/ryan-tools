class OArchive:
    pass
