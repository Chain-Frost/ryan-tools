class GeoSeries:
    pass
