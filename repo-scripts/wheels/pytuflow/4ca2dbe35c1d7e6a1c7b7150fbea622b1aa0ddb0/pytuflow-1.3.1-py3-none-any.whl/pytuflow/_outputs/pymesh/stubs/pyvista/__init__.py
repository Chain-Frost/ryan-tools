class PolyData:
    pass