class File:
    pass
