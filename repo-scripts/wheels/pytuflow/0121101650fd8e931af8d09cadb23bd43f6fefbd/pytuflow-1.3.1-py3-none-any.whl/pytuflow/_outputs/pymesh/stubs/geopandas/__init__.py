class GeoSeries:
    pass
