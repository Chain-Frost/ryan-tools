class PolyData:
    pass