class OArchive:
    pass
