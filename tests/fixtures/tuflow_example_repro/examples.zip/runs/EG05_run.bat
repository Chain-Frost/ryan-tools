set EXE_iSP=..\exe\2023-03-AF\TUFLOW_iSP_w64.exe
set EXE_iDP=..\exe\2023-03-AF\TUFLOW_iDP_w64.exe

start "TUFLOW" /wait   %EXE_iSP% -b    EG05_001.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_002.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_003.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_004.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_005.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_006.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_007.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_008.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_009.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_010.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_011.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_012.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_013.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_014.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_015.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_016.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_017.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG05_018.tcf
