@REM @echo off
setlocal
set "TUFLOW_EXE=C:\TUFLOW\2025.2.1\TUFLOW_iSP_w64.exe"

if not exist "%TUFLOW_EXE%" (
    echo ERROR: "%TUFLOW_EXE%" not found. Update Run_All_Examples.bat with the correct path.
    exit /b 1
)

pushd "%~dp0"
rem ----- Create_empties_run -----
@REM start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    Create_Empties

rem ----- EG04_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG04_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG04_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG04_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG04_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG04_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG04_006.tcf

rem ----- EG00_run -----
start "TUFLOW" /wait   "%TUFLOW_EXE%" -b    EG00_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG00_002.tcf

rem ----- EG01_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG01_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG01_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG01_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG01_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG01_007.tcf

rem ----- EG02_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_007.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_008.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_009.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_010.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_011.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_012.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_013.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_014.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_015.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_016.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_017.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_018.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%"  -b EG02_019.tcf

rem ----- EG03_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_007.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_008.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_009.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_010.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_011.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_012.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_013.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_014.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG03_015.tcf



rem ----- EG05_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_007.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_008.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_009.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_010.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_011.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_012.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_013.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_014.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_015.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_016.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_017.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG05_018.tcf

rem ----- EG06_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG06_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG06_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG06_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG06_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG06_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG06_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG06_007.tcf

rem ----- EG07_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG07_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG07_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG07_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG07_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG07_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG07_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG07_007.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG07_008.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG07_009.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG07_010.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG07_011.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG07_012.tcf

rem ----- EG08_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_007.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_008.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_009.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_010.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_011.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_012.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG08_013.tcf

rem ----- EG09_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG09_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG09_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG09_003.tcf

rem ----- EG10_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG10_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG10_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG10_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG10_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG10_007.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG10_008.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG10_009.tcf

rem ----- EG11_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b 	-e1 	Q100	 -e2	2hr		EG11_~e1~_~e2~_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b 	-e1 	QPMF	 -e2	2hr		EG11_~e1~_~e2~_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_007.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_008.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_009.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_010.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_011.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG11_012.tcf

rem ----- EG12_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_007.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_008.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_009.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_010.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_011.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_012.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG12_013.tcf

rem ----- EG13_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG13_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG13_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG13_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG13_004.tcf

rem ----- EG14_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG14_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG14_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG14_003.tcf

rem ----- EG15_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_000.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_007.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_008.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_009.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG15_010.tcf

rem ----- EG16_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b	 -s1  Exg			  EG16_~s1~_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b	 -s1  D01			  EG16_~s1~_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -s1  Exg  -s2  5m    EG16_~s1~_~s2~_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -s1  D01  -s2  5m    EG16_~s1~_~s2~_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -s1  Exg  -s2  2.5m  EG16_~s1~_~s2~_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -s1  D01  -s2  2.5m  EG16_~s1~_~s2~_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -s1  Exg  -s2  5m    EG16_~s1~_~s2~_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -s1  D01  -s2  5m    EG16_~s1~_~s2~_003.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -e1  Q100			  EG16_~e1~_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -e1  QPMF			  EG16_~e1~_004.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -e1  Q100 -e2	2hr   EG16_~e1~_~e2~_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -e1  Q100 -e2	4hr	  EG16_~e1~_~e2~_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -e1  QPMF -e2	2hr	  EG16_~e1~_~e2~_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -e1  QPMF -e2	4hr	  EG16_~e1~_~e2~_005.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -s1  Exg  -s2  5m  -e1  Q100 -e2  2hr  EG16_~s1~_~s2~_~e1~_~e2~_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -s1  D01  -s2  5m  -e1  Q100 -e2  4hr	EG16_~s1~_~s2~_~e1~_~e2~_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -s1  Exg  -s2  5m  -e1  QPMF -e2  2hr	EG16_~s1~_~s2~_~e1~_~e2~_006.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b  -s1  D01  -s2  5m  -e1  QPMF -e2  4hr	EG16_~s1~_~s2~_~e1~_~e2~_006.tcf

rem ----- EG17_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG17_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG17_002.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b    EG17_003.tcf

rem ----- EG18_run -----
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b EG18_001.tcf
start "TUFLOW" /MIN /wait   "%TUFLOW_EXE%" -b EG18_002.tcf
popd
echo.
echo All TUFLOW example runs completed.
