set EXE_iSP=..\exe\2023-03-AF\TUFLOW_iSP_w64.exe
set EXE_iDP=..\exe\2023-03-AF\TUFLOW_iDP_w64.exe

start "TUFLOW" /wait   %EXE_iSP% -b    EG10_003.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG10_004.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG10_005.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG10_006.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG10_007.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG10_008.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG10_009.tcf
