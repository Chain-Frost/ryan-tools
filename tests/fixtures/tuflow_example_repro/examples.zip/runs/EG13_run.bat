set EXE_iSP=..\exe\2023-03-AF\TUFLOW_iSP_w64.exe
set EXE_iDP=..\exe\2023-03-AF\TUFLOW_iDP_w64.exe

start "TUFLOW" /wait   %EXE_iSP% -b    EG13_001.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG13_002.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG13_003.tcf
start "TUFLOW" /wait   %EXE_iSP% -b    EG13_004.tcf
